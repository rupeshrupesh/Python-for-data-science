import sys
import subprocess
subprocess.call(['pip3','install','xgboost==1.7.5','joblib==1.2.0','scikit-learn==1.2.0','s3fs'])
import boto3
s3 = boto3.client('s3')
from pyathena import connect
import pandas as pd
import numpy as np
import joblib
import pickle
import warnings
warnings.filterwarnings('ignore')
from sklearn.preprocessing import OneHotEncoder
import scipy.stats.stats as stats
from datetime import datetime, date, timedelta
import xgboost as xgb
from xgboost import XGBClassifier
from s3fs.core import S3FileSystem

dataFrame = pd.read_json("s3://576118004139-parameterizing-master/Master.json")
l0_bucket = dataFrame.loc['l0-bucket','buckets']
l1_bucket = dataFrame.loc['l1-bucket','buckets']
l2_bucket = dataFrame.loc['l2-bucket','buckets']

# load pickle File
pkl1 = 's3://576118004139-ap-south-1-kbl-datamart-l2/datamartl2/Fixed_deposits_use_cases/FD_Renewal/picklefile/xgb_renewal.pkl'
s3_file = S3FileSystem()
xgb = joblib.load(s3_file.open(pkl1))

# read the input file
model = pd.read_parquet(f"s3://576118004139-ap-south-1-kbl-datamart-l2/datamartl2/Fixed_deposits_use_cases/FD_Renewal_SQLoutput/")
# check to remove deposits above 2Cr
model = model[model['deposit_amount']<20000000]
print(model.shape)

# to remove duplicates if any, get only one entry per acid basis maturity date.
model = model.groupby(['acid','maturity_date']).head(1)

# fill null values with 0
model.update(model[['active_loans','mb_no_of_td_roi_inquiries_3months','m1_avg','m2_avg','m3_avg','last_m12_avg','ci_ltd_l12m','ci_ftd_l12m','tot_ci_cr_tran_l3m','tot_ci_db_tran_l3m']].fillna(0))

# convert datatypes for some of the columns
model['tot_branch_induced_db_amt_l12m'] = model['tot_branch_induced_db_amt_l12m'].astype('float64')
model['tot_branch_induced_cr_amt_l12m'] = model['tot_branch_induced_cr_amt_l12m'].astype('float64')
model['tot_ci_amt_l12m'] = model['tot_ci_amt_l12m'].astype('float64')
model['amount_active_snapshot'] = model['amount_active_snapshot'].astype('float64')
model['amount_renewed_snapshot'] = model['amount_renewed_snapshot'].astype('float64')
model['amount_open_12months'] = model['amount_open_12months'].astype('float64')
model['amount_closed_12months'] = model['amount_closed_12months'].astype('float64')
model['max_interest_rate_lifetime'] = model['max_interest_rate_lifetime'].astype('float64')

# create last 12 month's branch to transaction amount ratio variable
model['branch_to_total_tran_amt_ratio_l12m'] = (model['tot_branch_induced_db_amt_l12m']+model['tot_branch_induced_cr_amt_l12m'])/(model['tot_branch_induced_db_amt_l12m']+model['tot_branch_induced_cr_amt_l12m']+model['tot_ci_amt_l12m'])

# update nulls 
model.update(model[['dp_code','region_name','occupation_desc']].fillna('NO_CODE'))
model['branch_to_total_tran_amt_ratio_l12m'] = model['branch_to_total_tran_amt_ratio_l12m'].fillna(0)

# create td roi req variable for last quarter
model['raised_td_roi_req_last_quarter'] = np.where(model['mb_no_of_td_roi_inquiries_3months'] > 0,1,0)

model = model[['acid', 'foracid', 'cust_id','maturity_date', 'deposit_amount','maturity_amount', 'clr_bal_amt', 'nrml_pcnt_cr','schm_code', 'schm_type', 'schm_desc', 'sol_id','acct_crncy_code', 'tenure', 'ren_srl_num','renewal_eligibility_flg','srl_num', 'srl_num_max',  'early_withdrawl_flg','renewal_amount','above_2cr_flg', 'tenure_bucket','active_loans','mb_no_of_td_roi_inquiries_3months', 'm1_avg', 'm2_avg', 'm3_avg','last_m12_avg', 'occupation_desc', 'age', 'dp_code', 'region_name','ci_ltd_l12m', 'ci_ftd_l12m', 'tot_ci_tran_l12m', 'tot_ci_cr_tran_l12m','tot_ci_db_tran_l12m', 'tot_ci_tran_days_l12m', 'tot_ci_cr_tran_days_l12m', 'tot_ci_db_tran_days_l12m','tot_ci_amt_l12m', 'tot_branch_induced_db_amt_l12m','tot_branch_induced_cr_amt_l12m', 'tot_ci_cr_tran_l3m','tot_ci_db_tran_l3m', 'accounts_open_12months','accounts_closed_12months', 'accounts_active_snapshot','accounts_renewed_snapshot', 'accounts_earlywithdrawn_snapshot','amount_active_snapshot', 'amount_renewed_snapshot', 'amount_open_12months', 'amount_closed_12months','preffered_tenure_lifetime', 'preffered_interest_rate_lifetime','max_interest_rate_lifetime','amount_in_preferred_interest_rate_lifetime','branch_to_total_tran_amt_ratio_l12m','raised_td_roi_req_last_quarter','mb_flg', 'ib_flg','active_casa','cust_gender', 'sub_category', 'parent_category']]

# data transformation
model['age'] = model['age'].fillna(-999)
model['mb_flg'] = model['mb_flg'].fillna('N')
model['ib_flg'] = model['ib_flg'].fillna('N')
model['active_casa'] = model['active_casa'].fillna(0)
model['cust_gender'] = model['cust_gender'].fillna('NO_DATA')
# model.isnull().sum()
print(model.shape)
model['parent_category'] = model['parent_category'].fillna('others')
model['sub_category'] = model['sub_category'].fillna('others')
# model.isnull().sum()
model = model.dropna()
# model.shape
print(model.shape)
model['adgbt_l12m'] = np.where(model['tot_ci_tran_days_l12m']>1,(((pd.to_datetime(model['ci_ftd_l12m'], errors='coerce') - pd.to_datetime(model['ci_ltd_l12m'], errors='coerce')).dt.days)/(model['tot_ci_tran_days_l12m']-1)).round(),366)

#12 Month
model['only_cr_l12m'] = np.where((model['tot_ci_cr_tran_l12m'] > 0) & (model['tot_ci_db_tran_l12m'] == 0),1,0)

model['cr_dr_ratio_l3m']  = np.where(model['tot_ci_db_tran_l3m'] > 0,model['tot_ci_cr_tran_l3m']/model['tot_ci_db_tran_l3m'],1)

model['m1_avg'] = model['m1_avg'].astype('float64')
model['m2_avg'] = model['m2_avg'].astype('float64')
model['m3_avg'] = model['m3_avg'].astype('float64')
model['last_m12_avg'] = model['last_m12_avg'].astype('float64')

model1 = model[(model['m1_avg']>=0.0)&(model['m2_avg']>=0.0)&(model['m3_avg']>=0.0)]
model1['m1_m3_mab_ratio']  = model1['m1_avg']/((model1['m1_avg']+model1['m2_avg']+model1['m3_avg'])/3) 
model1['m1_m12_mab_ratio']  = model1['m1_avg']/model1['last_m12_avg']

model1['branch_to_total_tran_amt_ratio_l12m'] = (model1['tot_branch_induced_db_amt_l12m']+model1['tot_branch_induced_cr_amt_l12m'])/(model1['tot_branch_induced_db_amt_l12m']+model1['tot_branch_induced_cr_amt_l12m']+model1['tot_ci_amt_l12m'])

model1['fd_opened_to_closed_ratio_by_amt'] = np.where(model1['amount_closed_12months'] > 0,model1['amount_open_12months']/model1['amount_closed_12months'],-999)

model1['active_fd_deposit_amt_to_last_month_casa_ratio'] = np.where(model1['m1_avg'] > 0.0,model1['amount_active_snapshot']/model1['m1_avg'],-999.0)


model1 = model1[['active_loans', 'adgbt_l12m', 'only_cr_l12m', 'cr_dr_ratio_l3m','m1_m3_mab_ratio', 'm1_m12_mab_ratio','branch_to_total_tran_amt_ratio_l12m','fd_opened_to_closed_ratio_by_amt','active_fd_deposit_amt_to_last_month_casa_ratio','raised_td_roi_req_last_quarter', 'm1_avg', 'last_m12_avg','accounts_open_12months', 'accounts_active_snapshot','accounts_earlywithdrawn_snapshot', 'accounts_renewed_snapshot','amount_renewed_snapshot', 'deposit_amount', 'srl_num', 'nrml_pcnt_cr', 'age',  'preffered_tenure_lifetime', 'preffered_interest_rate_lifetime','max_interest_rate_lifetime','amount_in_preferred_interest_rate_lifetime', 'tenure_bucket','renewal_amount','maturity_amount','deposit_amount','parent_category','sub_category']]

model1['total_active_loans'] = model1['active_loans']
model1['m1_m3_mab_ratio'] = model1['m1_m3_mab_ratio'].astype('float64')
model1['m1_m12_mab_ratio'] = model1['m1_m12_mab_ratio'].astype('float64')
model1['nrml_pcnt_cr'] = model1['nrml_pcnt_cr'].astype('float64')
model1['deposit_amount'] = model1['deposit_amount'].astype('float64')
model1['renewal_amount'] = model1['renewal_amount'].astype('float64')
model1['maturity_amount'] = model1['maturity_amount'].astype('float64')
model1['preffered_interest_rate_lifetime'] = model1['preffered_interest_rate_lifetime'].astype('float64')
model1['amount_in_preferred_interest_rate_lifetime'] = model1['amount_in_preferred_interest_rate_lifetime'].astype('float64')

num_cols = model1.head().select_dtypes('number').columns
num_cols_final = [i for i in num_cols]

data_1 = model1[num_cols_final]
data_1.shape
print(data_1.shape)
cat_cols = model1.select_dtypes(include='object')
# cat_cols.shape

# perform one hot encoding on the categorical columns
one_hot_encoded = pd.get_dummies(cat_cols)

# merge the one hot encoded columns with the original dataframe
model2 = pd.concat([data_1, one_hot_encoded], axis=1)

model2['age'] = np.where(model2['age']>90,90,model1['age'])
model2['age'] = np.where(model2['age']<18,18,model1['age'])

model2 = model2[['total_active_loans', 'adgbt_l12m', 'only_cr_l12m', 'cr_dr_ratio_l3m','m1_m3_mab_ratio', 'm1_m12_mab_ratio','branch_to_total_tran_amt_ratio_l12m','fd_opened_to_closed_ratio_by_amt','active_fd_deposit_amt_to_last_month_casa_ratio','raised_td_roi_req_last_quarter', 'preffered_interest_rate_lifetime','amount_in_preferred_interest_rate_lifetime','max_interest_rate_lifetime', 'm1_avg', 'last_m12_avg','accounts_open_12months', 'accounts_active_snapshot','accounts_earlywithdrawn_snapshot', 'accounts_renewed_snapshot','amount_renewed_snapshot', 'deposit_amount', 'srl_num', 'nrml_pcnt_cr','age', 'preffered_tenure_lifetime_2 to 3 years','preffered_tenure_lifetime_7 to 90 days','preffered_tenure_lifetime_91 to 180 days','tenure_bucket_181 to 364 days', 'tenure_bucket_2 to 3 years','tenure_bucket_7 to 90 days', 'tenure_bucket_91 to 180 days','renewal_amount','maturity_amount']]

model2.columns = ['total_active_loans', 'adgbt_l12m', 'only_cr_l12m', 'cr_dr_ratio_l3m','m1_m3_mab_ratio', 'm1_m12_mab_ratio','branch_to_total_tran_amt_ratio_l12m','fd_opened_to_closed_ratio_by_amt','active_fd_deposit_amt_to_last_month_casa_ratio', 'raised_td_roi_req_last_quarter', 'preferred_interest_rate_lifetime','amount_in_preferred_interest_rate_lifetime','max_interest_rate_lifetime', 'm1_avg', 'last_m12_avg','accounts_open_12months', 'accounts_active_snapshot','accounts_earlywithdrawn_snapshot', 'accounts_renewed_snapshot', 'amount_renewed_snapshot', 'deposit_amount', 'deposit_amount_x','deposit_amount_y', 'deposit_amount_z', 'srl_num', 'nrml_pcnt_cr', 'age','preferred_tenure_lifetime_2 to 3 years','preferred_tenure_lifetime_7 to 90 days','preferred_tenure_lifetime_91 to 180 days','tenure_bucket_181 to 364 days', 'tenure_bucket_2 to 3 years','tenure_bucket_7 to 90 days', 'tenure_bucket_91 to 180 days','renewal_amount',  'maturity_amount']

model2 = model2[['total_active_loans', 'adgbt_l12m', 'only_cr_l12m', 'cr_dr_ratio_l3m','m1_m3_mab_ratio', 'm1_m12_mab_ratio','branch_to_total_tran_amt_ratio_l12m','fd_opened_to_closed_ratio_by_amt','active_fd_deposit_amt_to_last_month_casa_ratio','raised_td_roi_req_last_quarter', 'preferred_interest_rate_lifetime','amount_in_preferred_interest_rate_lifetime','max_interest_rate_lifetime', 'm1_avg', 'last_m12_avg', 'accounts_open_12months', 'accounts_active_snapshot','accounts_earlywithdrawn_snapshot', 'accounts_renewed_snapshot','amount_renewed_snapshot', 'deposit_amount', 'srl_num', 'nrml_pcnt_cr','age', 'preferred_tenure_lifetime_2 to 3 years', 'preferred_tenure_lifetime_7 to 90 days','preferred_tenure_lifetime_91 to 180 days','tenure_bucket_181 to 364 days', 'tenure_bucket_2 to 3 years','tenure_bucket_7 to 90 days', 'tenure_bucket_91 to 180 days','renewal_amount','maturity_amount']]


X_oot = model2.drop(['renewal_amount','maturity_amount'],axis=1)

y_pred_proba_oot = xgb.predict_proba(X_oot)[:, 1]
oot_pred = xgb.predict(X_oot)

oot = pd.DataFrame()
oot['y_pred_proba_oot'] = y_pred_proba_oot
oot['oot_pred'] = oot_pred
# oot.head(),oot.shape
oot_dataset = X_oot.copy() 
oot_dataset['Predictions'] = y_pred_proba_oot.tolist()

oot_dataset['cust_id'] = model['cust_id']
oot_dataset['Deciles']=10-pd.qcut(oot_dataset["Predictions"],10,duplicates='drop', labels=False)

model['Deciles'] = oot_dataset['Deciles']
model['Predictions'] = oot_dataset['Predictions']

# top_2_buckets = model[model['Deciles'].isin([1,2,3,4,5,6])]
#CHANGED ON AUG 3RD 2024: DECILES 3-7 SMS, EMAIL, SMS+EMAIL
top_2_buckets = model[model['Deciles'].isin([3,4,5,6,7])]
#buckets3_6 = model[(model['Deciles'].isin([3,4,5,6]))]

print(top_2_buckets.shape)
#print(buckets3_6.shape)
top_2_buckets = top_2_buckets[['cust_id','foracid','acid','maturity_date','deposit_amount','maturity_amount','sol_id','active_loans','m1_avg','age','dp_code','mb_flg', 'ib_flg', 'active_casa', 'cust_gender','accounts_active_snapshot','sub_category','parent_category']]

print(top_2_buckets['cust_id'].nunique())
print(len(top_2_buckets))
#buckets3_6 = buckets3_6[['cust_id','foracid','acid','maturity_date','deposit_amount','maturity_amount','sol_id','active_loans','m1_avg','age','dp_code','mb_flg', 'ib_flg', 'active_casa', 'cust_gender','accounts_active_snapshot','sub_category','parent_category']]

#buckets3_6 = buckets3_6.sort_values(by=['cust_id','maturity_date'])

#buckets3_6['maturity_date1'] = buckets3_6['maturity_date'].dt.strftime('%Y-%m-%d')

#buckets3_6['deposit_amount'] = buckets3_6['deposit_amount'].astype('int64')

#buckets3_6['deposit_amount'] = buckets3_6['deposit_amount'].astype(str)
#print(buckets3_6.shape,buckets3_6['acid'].nunique(),"buckets3_6 shape and acid count")

#first_3_6 = buckets3_6.groupby(['cust_id','sol_id']).first().reset_index()
#print(first_3_6.shape)

#remaining = buckets3_6[~buckets3_6['acid'].isin(first_3_6['acid'].values)]
#print(remaining.shape)


#remaining['maturity_date1'] = remaining['maturity_date'].dt.strftime('%d-%m-%Y')


# def concat_strings(series):
#     return  '| '.join(series)

# def check_count():
#     if remaining.shape[0]>0:
#         grouped = remaining.groupby(['cust_id','sol_id']).agg(foracids=('foracid',concat_strings),
#                                                               acids=('acid',concat_strings),
#                                                       maturity_dates=('maturity_date1',concat_strings),
#                                                               deposit_amounts=('deposit_amount',concat_strings)).reset_index()
#     else:
#         grouped = pd.DataFrame(columns =['cust_id','sol_id','foracids','acids','maturity_dates','deposit_amounts'])
#     return grouped

# grouped = check_count()


# grouped_othrs = first_3_6.groupby(['cust_id','sol_id'])[['active_loans','m1_avg','age','dp_code',
#                                                           'accounts_active_snapshot','mb_flg', 'ib_flg', 'active_casa', 'cust_gender', 'sub_category',
#         'parent_category']].first().reset_index()


# first_3_6 =first_3_6[['cust_id', 'sol_id', 'foracid', 'acid', 'maturity_date',
#       'deposit_amount']]


# branch_first = pd.merge(first_3_6,grouped_othrs,on=['cust_id','sol_id'],how='inner')

# branch = pd.merge(branch_first,grouped,on=['cust_id','sol_id'],how='left')



# branch.columns = ['cust_id', 'sol_id', 'foracid', 'acid', 'maturity_date','deposit_amount','active_loans', 'm1_avg', 'age', 'dp_code', 
#               'active_FDs','mb_flg', 'ib_flg', 'active_casa', 'cust_gender','sub_category', 'parent_category', 
#                   'foracids', 'acids','maturity_dates', 'deposit_amounts']

# branch = branch[['cust_id', 'sol_id', 'foracid', 'acid', 'maturity_date','deposit_amount','m1_avg', 'age','mb_flg', 'ib_flg', 'dp_code', 'active_FDs',
#               'active_loans','active_casa', 'cust_gender','sub_category', 'parent_category',
#                 'foracids', 'acids','maturity_dates', 'deposit_amounts']]

top_2_buckets.columns =['cust_id', 'foracid', 'acid', 'maturity_date', 'deposit_amount','maturity_amount', 'sol_id', 
                    'active_loans', 'm1_avg', 'age', 'dp_code','mb_flg', 'ib_flg', 'active_casa', 'cust_gender','active_FDs','sub_category','parent_category']

top_2_buckets = top_2_buckets[['cust_id', 'sol_id', 'foracid', 'acid', 'maturity_date','deposit_amount','m1_avg', 'age','mb_flg' 
                               ,'ib_flg', 'dp_code', 'active_FDs','active_loans','active_casa', 'cust_gender','sub_category','parent_category']]


email = top_2_buckets.copy()
# sms = top_2_buckets.copy()

from pandas.tseries.offsets import DateOffset
from datetime import datetime, timedelta
    

email['event_date'] = pd.to_datetime(email['maturity_date'])- timedelta(days=2)
# sms['event_date'] = pd.to_datetime(sms['maturity_date'])- timedelta(days=2)


#branch['event_date'] = pd.to_datetime(branch['maturity_date']) - timedelta(days=3)
#branch['event_date'] = branch['event_date'].dt.strftime('%Y-%m-%d')

#branch.loc[branch['maturity_dates'].isnull(),'campaign_end_date'] = branch['maturity_date']
#branch.loc[branch['maturity_dates'].notnull(),'campaign_end_date'] = branch['maturity_date']
#branch.loc[branch['maturity_dates'].isnull(),'campaign_end_date'] = branch['maturity_date']

#branch_null = branch[branch['maturity_dates'].isnull()]
#branch_not_null = branch[~branch['maturity_dates'].isnull()]

#print(branch_null.shape,branch_not_null.shape,'branch_not_null and null counts')


#campaign_end_date = []
# for x in branch_not_null['maturity_dates']:
#     if len(x.split('|'))==1:
#         campaign_end_date.append(x.split('|')[0])
#     else:
#         campaign_end_date.append(x.split('|')[-1])

# branch_not_null['campaign_end_date'] = campaign_end_date
# print(branch_not_null['campaign_end_date'].head(1))
# branch_not_null['campaign_end_date'] = pd.to_datetime(branch_not_null['campaign_end_date'].str.strip(),errors='coerce',format='%d-%m-%Y').dt.strftime('%Y-%m-%d')
# print('check here')
# branch_not_null.head(15)


# # In[123]:


# branch = pd.concat([branch_null,branch_not_null],axis=0)
# branch.shape


# In[124]:


#branch.head(15)


# In[125]:


email['campaign_end_date'] = email['event_date']
# sms['campaign_end_date'] = sms['event_date']


# In[126]:


#branch['channel'] = "BB"
email['channel'] = "EMAIL"
# sms['channel'] = "SMS"

# branch['unique_id'] = np.nan
# branch['lead_source'] = 'Analytics'
# branch['campaign_name'] = 'FD Renewal'
# branch['campaign_type'] = 'High Propensity of FD Renewal'
# branch['base_product'] = 'FD'
# branch['crosssell_product'] = 'FD'
# branch['customer_id'] = branch['cust_id']
# branch['sol_id'] = branch['sol_id']
# branch['empid'] = np.nan
# branch['channel'] = 'BB'
# branch['campaign_id'] = 'CAMFD0002'
# branch['campaign_start_date'] = datetime.now().strftime("%Y-%m-%d")
# branch['campaign_end_date'] = branch['campaign_end_date']
# branch['mb_registered'] = np.nan
# branch['ib_registered'] = np.nan
# branch['additional_information_1'] = 'Reach out to the Individual saving account customer on Event date and do the follow up till his Maturity date - as these are the customers having high chances to renew their FDs'
# branch['additional_information_2'] = 'FD Deposit amount: '+branch['deposit_amount'].astype(str)
# branch['additional_information_3'] = 'FD Maturity Date: '+pd.to_datetime(branch['maturity_date']).dt.strftime('%d-%m-%Y')
# branch['additional_information_4'] = 'Last Months average Balance in savings account(s): '+branch['m1_avg'].astype(str)
# branch['additional_information_5'] = 'Number of Active Savings account(s): '+branch['active_casa'].astype(str)
# branch['additional_information_6'] = 'Number of Active loan account(s): '+branch['active_loans'].astype(str)
# branch['additional_information_7'] = 'Customer Segment: '+branch['parent_category'].astype(str)
# branch['additional_information_8'] = 'Other FDs maturing in the same month: '+branch['foracids'].astype(str)
# branch['additional_information_9'] = 'Deposits of Other FDs maturing in the same month: '+branch['deposit_amounts'].astype(str)
# branch['additional_information_10'] = 'Maturity Dates of Other FDs maturing in the same month: '+branch['maturity_dates'].astype(str)
# branch['event_date'] = pd.to_datetime(branch['maturity_date']) - timedelta(days=4)
# branch['event_date'] = branch['event_date'].dt.strftime('%Y-%m-%d')
# branch['account_nbr'] = branch['foracid']
# branch['balance'] = np.nan
# branch['due_date'] = pd.to_datetime(branch['maturity_date']).dt.strftime('%Y-%m-%d')
# branch['payment_link'] = np.nan
# branch['dm_flag'] = np.nan
# branch['dm_date'] = np.nan
# branch['lead_status'] = np.nan
# branch['lead_status_2'] = np.nan
# branch['disposition_description_1'] = np.nan
# branch['disposition_description_2'] = np.nan
# branch['disposition_description_3'] = np.nan
# branch['disposition_description_4'] = np.nan
# branch['disposition_description_5'] = np.nan
# branch['disposition_timestamp'] = np.nan

# leads_br = branch.copy()
# np.random.seed(42)
# shuffled_leads_br = leads_br.sample(frac=1)
# split_size = len(shuffled_leads_br)//4

# leads_br_set1 = shuffled_leads_br.iloc[:split_size].copy()
# leads_br_set2 = shuffled_leads_br.iloc[split_size:2*split_size].copy()
# leads_br_set3 = shuffled_leads_br.iloc[2*split_size:3*split_size].copy()
# leads_br_set4 = shuffled_leads_br.iloc[3*split_size:].copy()

# leads_br_set4_2 = leads_br_set4.copy()

# leads_br_set2['channel'] = 'SMS'
# leads_br_set3['channel'] = 'EMAIL'

# leads_br_set4['channel'] = 'SMS'
# leads_br_set4_2['channel'] = 'EMAIL'

email['unique_id'] = np.nan
email['lead_source'] = 'Analytics'
email['campaign_name'] = 'FD Renewal'
email['campaign_type'] = 'High Propensity of FD Renewal'
email['base_product'] = 'FD'
email['crosssell_product'] = 'FD'
email['customer_id'] = email['cust_id']
email['sol_id'] = email['sol_id']
email['empid'] = np.nan
email['channel'] = 'EMAIL'
email['campaign_id'] = 'CAMFD0002'
email['campaign_start_date'] = datetime.now().strftime("%Y-%m-%d")
email['campaign_end_date'] = email['maturity_date']
email['mb_registered'] = np.nan
email['ib_registered'] = np.nan
email['additional_information_1'] = np.nan
email['additional_information_2'] = np.nan
email['additional_information_3'] = np.nan
email['additional_information_4'] = np.nan
email['additional_information_5'] = np.nan
email['additional_information_6'] = np.nan
email['additional_information_7'] = np.nan
email['additional_information_8'] = np.nan
email['additional_information_9'] = np.nan
email['additional_information_10'] = np.nan
email['event_date'] = pd.to_datetime(email['maturity_date']) - timedelta(days=2)
email['event_date'] = email['event_date'].dt.strftime('%Y-%m-%d')
email['account_nbr'] = email['foracid']
email['balance'] = np.nan
email['due_date'] = pd.to_datetime(email['maturity_date']).dt.strftime('%Y-%m-%d')
email['payment_link'] = np.nan
email['dm_flag'] = np.nan
email['dm_date'] = np.nan
email['lead_status'] = np.nan
email['lead_status_2'] = np.nan
email['disposition_description_1'] = np.nan
email['disposition_description_2'] = np.nan
email['disposition_description_3'] = np.nan
email['disposition_description_4'] = np.nan
email['disposition_description_5'] = np.nan
email['disposition_timestamp'] = np.nan

leads_digital = email.copy()
np.random.seed(42)
shuffled_leads_digital = leads_digital.sample(frac=1)
split_size = len(shuffled_leads_digital)//3

leads_digital_set1 = shuffled_leads_digital.iloc[:split_size].copy()
leads_digital_set2 = shuffled_leads_digital.iloc[split_size:2*split_size].copy()
leads_digital_set3 = shuffled_leads_digital.iloc[2*split_size:].copy()

leads_digital_set3_2 = leads_digital_set3.copy()

leads_digital_set1['channel'] = 'SMS'
leads_digital_set2['channel'] = 'EMAIL'

leads_digital_set3['channel'] = 'SMS'
leads_digital_set3_2['channel'] = 'EMAIL'

leads_digital_set1['event_date'] = pd.to_datetime(leads_digital_set1['maturity_date']) - timedelta(days=2)
leads_digital_set3['event_date'] = pd.to_datetime(leads_digital_set3['maturity_date']) - timedelta(days=2)
# leads_br_set4['event_date'] = pd.to_datetime(leads_br_set4['maturity_date']) - timedelta(days=2)
# leads_br_set2['event_date'] = pd.to_datetime(leads_br_set2['maturity_date']) - timedelta(days=2)

leads_digital_set1['event_date'] = leads_digital_set1['event_date'].dt.strftime('%Y-%m-%d')
leads_digital_set3['event_date'] = leads_digital_set3['event_date'].dt.strftime('%Y-%m-%d')
# leads_br_set4['event_date'] = leads_br_set4['event_date'].dt.strftime('%Y-%m-%d')
# leads_br_set2['event_date'] = leads_br_set2['event_date'].dt.strftime('%Y-%m-%d')

# final_campaign_data = pd.concat([target2,email,sms],axis=0)
# final_campaign_data = pd.concat([leads_br,leads_br_set2,leads_br_set3,leads_br_set4,leads_br_set4_2,leads_digital_set1,leads_digital_set2,leads_digital_set3,leads_digital_set3_2],axis=0)

final_campaign_data = pd.concat([leads_digital_set1,leads_digital_set2,leads_digital_set3,leads_digital_set3_2],axis=0)

# create columns with current date and Control
final_campaign_data['current_date'] = datetime.now().strftime("%Y-%m-%d")
final_campaign_data['Control'] = np.where(final_campaign_data['cust_id'].str.endswith('9'),'Y','N')

# re-arrange all the columns as per leads table
final_campaign_data = final_campaign_data[['unique_id', 'lead_source', 'campaign_name', 'campaign_type','base_product', 'crosssell_product', 'customer_id', 'sol_id', 'empid','channel', 'campaign_id', 'campaign_start_date', 'campaign_end_date','mb_registered', 'ib_registered', 'additional_information_1','additional_information_2', 'additional_information_3', 'additional_information_4', 'additional_information_5', 'additional_information_6', 'additional_information_7','additional_information_8', 'additional_information_9', 'additional_information_10', 'event_date', 'account_nbr', 'balance','due_date', 'payment_link', 'dm_flag', 'dm_date', 'lead_status','lead_status_2','disposition_description_1','disposition_description_2', 'disposition_description_3','disposition_description_4', 'disposition_description_5','disposition_timestamp','Control', 'current_date']]

final_campaign_data.to_csv(f"s3://576118004139-ap-south-1-kbl-datamart-l2/datamartl2/Fixed_deposits_use_cases/FD_Renewal/model_output_files/renewal_campaign_data.csv",index=False,header=False)



