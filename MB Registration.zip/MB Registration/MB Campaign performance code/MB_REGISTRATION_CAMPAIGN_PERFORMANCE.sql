--Conctact Center`
--Change the event date at two instance
--Change the Year and Month accordingly
with cc_data as (
select a.customer_id, a.sol_id, f.region_name,
coalesce(c.contacted, 0) as contacted,
coalesce(d.registered,0) as registered,
coalesce(e.activated,0) as activated,
coalesce(c.Interested,0) as interested,
coalesce(c.contacted_w_exclsns,0) as contacted_w_exclsns,
case when c.interested = 1 and registered =1 then 1 else 0 end as interested_registered,
case when c.interested = 1 and registered =1 and activated=1 then 1 else 0 end as interested_activated,
case when contacted  =1 and registered = 1 then 1 else 0 end as contacted_registered,
case when contacted =1 and registered =1 and activated=1 then 1 else 0 end as contacted_activated ,
case when contacted_w_exclsns  =1 and registered = 1 then 1 else 0 end as contacted_excl_registered,
case when contacted_w_exclsns =1 and registered =1 and activated=1 then 1 else 0 end as contacted_excl_activated 
from ( 
Select * from
l2karnatakabankdb.acoe_crm_leads_prod  
where campaign_name = 'Mobile Banking Registration' and channel = 'CC' and lead_status in ('Converted','In Process','Dead', 'New') and event_date = date('2024-02-27')
)a 
left join (
select customer_id,1 as contacted, 
case when disposition_description_4 in ('Interested','Registered') then 1 else 0 end as interested ,
case when disposition_description_4 in ('Call Back', 'Wrong Number', 'Language Barrier','Not Interested') then 0 else 1 end as contacted_w_exclsns
from  l2karnatakabankdb.acoe_crm_leads_prod  
where campaign_name = 'Mobile Banking Registration' and channel = 'CC' and lead_status in ('Converted','In Process','Dead') and event_date = date('2024-02-27')
) c on a.customer_id = c.customer_id
left join (
select distinct user_id, 1 as registered from l0karnatakabankdb.users where status in ('R', 'A', 'B', 'L') 
and year(cr_on)=2024 and month(cr_on) in (1,2,3)
)d on trim(a.customer_id) = trim(d.user_id)
left join (
select distinct user_id, 1 as activated from l0karnatakabankdb.users where status in ('R', 'A', 'B', 'L') and year(cr_on)=2024 and month(cr_on) in (1,2,3) and user_id in (select distinct user_id from l0karnatakabankdb.mobileusershist)
)e on trim(a.customer_id) = trim(e.user_id)
left join l0karnatakabankdb.service_outlet_table f on lpad(cast(a."sol_id" as varchar),3,'0') =  f.sol_id
)
select region_name,
count(distinct customer_id) as total_leads,
sum(contacted) as contacted,
sum(contacted_w_exclsns) as "contacted(excl Call Back, Language Barrier, Wrong Number)",
sum(contacted_registered) as "registered (out of connected)",
sum(contacted_activated) as "activated (out of connected)",
sum(contacted_excl_registered) as "registered (out of connected excl Call Back, Language Barrier, Wrong Number)",
sum(contacted_excl_activated) as "activated (out of connected excl Call Back, Language Barrier, Wrong Number)",
sum(registered) as "registered (out of total allocated)",
sum(activated) as "activated (out of total allocated)",
sum(interested) as interested,
sum(interested_registered) as "registered (out of interested)",
sum(interested_activated) as "activated (out of interested)"
from cc_data
group by 1 order by 1

--- Branch
-- Change the event date
with br_data as
(select a.*,
coalesce(d.registered,0) as registered,
coalesce(e.activated,0) as activated,
case when a.attempted = 1 and registered = 1 then 1 else 0 end as registered_attempted,
case when a.attempted = 1 and registered = 1 and activated  = 1 then 1 else 0 end as activated_attempted,
f.region_name,
--g.cluster_head,
g.cluster
from
(select *, case when lead_status in ('Dead','In Process', 'Converted') then 1 else 0 end  as attempted 
from l2karnatakabankdb.acoe_crm_leads_prod  
where campaign_name in ('Mobile Banking Registration') and channel = 'BB' and event_date in (date('2024-03-06'))
) a 
left join
(select distinct user_id, 1 as registered from l0karnatakabankdb.users where status in ('R', 'A', 'B', 'L') and year(cr_on)=2023 and month(cr_on) in (1,2,3)
) d
on a.customer_id = trim(d.user_id)
left join
(select distinct user_id, 1 as activated from l0karnatakabankdb.users where status in ('R', 'A', 'B', 'L') and year(cr_on)=2024 and month(cr_on) in (1,2,3)
and user_id in (select distinct user_id from l0karnatakabankdb.mobileusershist)
) e
on d.user_id = e.user_id
left join
l0karnatakabankdb.service_outlet_table f
on a.sol_id = f.sol_id
left join
l2karnatakabankdb.cluster_heads g
on a.sol_id = g.sol_id
)
select region_name,
count(distinct customer_id) as total_leads,
sum(attempted) as attempted,
sum(registered) as registered,
sum(activated) as activated,
sum(registered_attempted) as "registered (attempted)",
sum(activated_attempted) as "activated (attempted)"
from br_data
group by 1 order by 1



with br_data as
(select a.*,
coalesce(d.registered,0) as registered,
coalesce(e.activated,0) as activated,
f.region_name,
f.sol_desc,
f.dp_code,
--g.cluster_head,
g.cluster
--g.bh_name
from
(select *, case when lead_status in ('Dead','In Process', 'Converted') then 1 else 0 end  as attempted 
from l2karnatakabankdb.acoe_crm_leads_prod 
where campaign_name in ('Mobile Banking Registration') and channel = 'BB' and event_date in (date('2024-03-06'))
) a 
left join
(select distinct user_id, 1 as registered from l0karnatakabankdb.users where status in ('R', 'A', 'B', 'L') and year(cr_on)=2024 and month(cr_on) in (1,2,3)
) d
on a.customer_id = trim(d.user_id)
left join
(select distinct user_id, 1 as activated from l0karnatakabankdb.users where status in ('R', 'A', 'B', 'L') and year(cr_on)=2024 and month(cr_on) in (1,2,3)
and user_id in (select distinct user_id from l0karnatakabankdb.mobileusershist)
) e
on d.user_id = e.user_id
left join
l0karnatakabankdb.service_outlet_table f
on a.sol_id = f.sol_id
left join
(select * from l2karnatakabankdb.cluster_heads where sol_id != 'SOL_ID') g
on cast(a.sol_id as int) = cast(g.sol_id as int)
)
select 
sol_id,
sol_desc as "Branch Name",
region_name as "Region",
dp_code,
cluster,
--cluster_head,
--bh_name as "Branch Head",
count(distinct customer_id) as total_leads,
sum(attempted) as attempted,
sum(registered) as registered,
sum(activated) as activated
from br_data
group by 1,2,3,4,5 order by 1

---- control group performance
Select count(*) from l2karnatakabankdb.acoe_crm_mb_registration_bkp 

with test_control_perf as
(select a.*,
e.region_name,
coalesce(b.branch_leads_crm,0) as branch_leads_crm,
coalesce(d.registered,0) as registered,
coalesce(e.activated,0) as activated
from
(select distinct * from (select * from l2karnatakabankdb.acoe_crm_mb_registration_bkp) union all (select * from l2karnatakabankdb.acoe_crm_mb_registration)) a
left join
(select distinct user_id, 1 as registered from l0karnatakabankdb.users where status in ('R', 'A', 'B', 'L') and year(cr_on)=2024 and month(cr_on) in (1,2,3)
) d
on trim(a.customer_id) = trim(d.user_id)
left join
(select distinct user_id, 1 as activated from l0karnatakabankdb.users where status in ('R', 'A', 'B', 'L') and year(cr_on)=2024 and month(cr_on) in (1,2,3)
and user_id in (select distinct user_id from l0karnatakabankdb.mobileusershist)
) e
on trim(d.user_id) = e.user_id
left join
(select customer_id, 1 as branch_leads_crm from l2karnatakabankdb.acoe_crm_leads_prod where campaign_name = 'Mobile Banking Registration'and channel = 'BB' and event_date in (date('2024-03-06'))
) b
on a.customer_id = b.customer_id
left join
(select sol_id, region_name from l0karnatakabankdb.service_outlet_table) e
on a.sol_id = e.sol_id
)
select channel,
region_name,
control,
branch_leads_crm,
count(distinct customer_id) as total_leads,
sum(registered) as registered,
sum(activated) as activated
from test_control_perf
group by 1,2,3,4