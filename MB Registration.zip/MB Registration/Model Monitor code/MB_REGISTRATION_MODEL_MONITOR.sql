--Model Monitoring Query
-- The following needs to be modified before editing
---1. Table name
---2. S3 Path
---3. Snapshot date - (17 Instance)
------For Model Monitoring the snapshot date should be  current month - 6  months, as we are considering a 6 month performance period.
---4. Previous Year date- (1 Instance)
--------This should be exactly one year less than of Snapshot date
---5. Dependent variable calc date - (1 Instance)

CREATE TABLE IF NOT EXISTS  "l2karnatakabankdb"."mb_reg_model_monitor_cohort_data_feb2024" 
WITH (format='PARQUET', external_location= 's3://576118004139-ap-south-1-kbl-datamart-l2/datamartl2/MB_Registration_Model/model_monitoring_cohort_data/Feb2024/') AS
with cellphone_avbl_base_unique as (
SELECT *,
Row_number() over (partition by "ORGKEY" order by "ORGKEY","TMDATE" desc) as "rownum"
FROM "l0karnatakabankdb"."phoneemail"
where "PHONENOLOCALCODE" is not null  and "PHONEOREMAIL" = 'PHONE' 
AND "PHONEEMAILTYPE" = 'CELLPH' and date(tmdate) <= date ('2023-08-31')
),
eligible_base_1 as (
select a."CUST_ID", 
a."ACID",
a."MODE_OF_OPER_CODE", 
a."ACCT_OPN_DATE",
a."CLR_BAL_AMT",
b."cust_constitution_code",
b."CUST_DOB",
--case when a."SCHM_TYPE" = 'SBA' and b."CUSTOMERMINOR_ID" >= 216 then 'N'
--when a."SCHM_TYPE" = 'CAA' then 'N'
case when  b."CUSTOMERMINOR_ID" >= 216 then 'N'
else 'Y' end  as "CUST_MINOR_FLG",
b."cust_nationality",
b."cust_occupation_code",
b."cust_rel_start_date",
b."CUST_TYPE",
a."SCHM_TYPE" ,
a."SCHM_CODE",
a."FREZ_CODE",
a."SOL_ID",
c."ACCT_STATUS",
d."reg_flg",
d."CR_ON" as "REG_DATE",
phone."cellph_flg"
--d.*
from
(Select *
from "l0karnatakabankdb"."GENERAL_ACCT_MAST_TABLE"
where "SCHM_TYPE" in ('SBA', 'CAA')
and date("ACCT_OPN_DATE") <= date ('2023-08-31') ---***** UPDATE to snapshot date ******
and "ACCT_OWNERSHIP" <> 'O' and "SCHM_CODE" not in ('HDD11', 'SBWAL') 
and ("ACCT_CLS_FLG" <> 'Y' or date("ACCT_CLS_DATE") > date ('2023-08-31')) ---***** UPDATE to snapshot date ******
--and "GL_SUB_HEAD_CODE" <> '25061'
) a
left join
(select "CUST_ID", 
"cust_constitution_code", 
"CUST_DOB", 
"cust_occupation_code",
"cust_rel_start_date", 
"CUST_TYPE",
date_diff('month',date("CUST_DOB"),date('2023-08-31')) as "CUSTOMERMINOR_ID",
"cust_nationality"
from "l1karnatakabankdb"."customer_base") b
on a."CUST_ID" = b."CUST_ID"
left join
(select "ACID", "ACCT_STATUS" from "l0karnatakabankdb"."SBCA_MAST_TABLE") c
on a."ACID" = c."ACID"
left join
(select "ORGKEY", 1 as "cellph_flg"
from cellphone_avbl_base_unique
where "rownum" <2) phone
on a."CUST_ID" = phone."ORGKEY"
left join 
(select distinct "USER_ID", "CR_ON", 'Y' as "REG_FLG" from "l0karnatakabankdb"."users"
where status in ('R', 'A', 'B', 'L')
and date("CR_ON") <= date ('2023-08-31')) d   ---***** UPDATE to snapshot date ******
on trim(a."CUST_ID") = trim(d."USER_ID")
),
eligible_base_2 as (
select *,
case when 
(("CUST_TYPE" not in ('11','12') 
and "cust_constitution_code" not in ('155','05','06') 
and ("CUST_MINOR_FLG" = 'N' or ("CUST_MINOR_FLG" is null and "SCHM_TYPE" = 'CAA'))
and "cust_nationality" = 'N'
and ("FREZ_CODE" not in ('D','C','T') OR "FREZ_CODE" is null)
and "MODE_OF_OPER_CODE" in ('01','03','04','13','16','34','62','67','68')
and "SCHM_CODE" in 
('SBSLE','SBSLP','SBSLC','SBILS','SBPLA','SBPRV',
'CARUB','CADIA','CADMD','CAGEN','CAPLA','CAPRL','CARBY','SBSAL','SBSPR','SBSTF','SBGEN'
,'SBTRN','SBVNT', 'CASPR','CAPRV','SBNMB','SBSUG','SBRUB','CADIP'
))
and 
(("cellph_flg" = 1 
and 
DATE_DIFF('month', coalesce(date("CUST_DOB"),current_date),  date ('2023-08-31') ) < 720) ---***** UPDATE to snapshot date ******
or "reg_flg" = 'Y') 
and ("ACCT_STATUS" <> 'D' or "reg_flg" = 'Y'))
or "reg_flg" = 'Y'
then 'Y'
else 'N' end as "mb_elig_flg_fnl"
from eligible_base_1
),
eligible_base_3 as (
select *,
case when date("ACCT_OPN_DATE") <= date('2022-06-30')
and (date("REG_DATE") is null or date("REG_DATE") > date('2023-08-31'))
--and ("ACCT_STATUS" <> 'D' or ("reg_flg" = 'Y' and "REG_DATE" <= cast('2023-08-31' as date)))
and "mb_elig_flg_fnl" = 'Y'
then 'Y'
else 'N' end as "cohort_flg"
from eligible_base_2
),
eligible_base_fnl as (
Select * from eligible_base_3 where "cohort_flg" = 'Y'
),
tran_data_base as (
select a."TRAN_DATE" ,
a."TRAN_ID",
a."DEL_FLG",
a."TRAN_TYPE",
a."TRAN_SUB_TYPE",
a."PART_TRAN_TYPE",
a."TRAN_AMT",
a."TRAN_PARTICULAR",
a."TRAN_RMKS",
a."cust_id",
a."RCRE_USER_ID",
(select "delivery_channel_id" from "l0karnatakabankdb"."hth_table" b where a."TRAN_DATE"  = b."TRAN_DATE" and a."TRAN_ID" = b."TRAN_ID" ) as "delivery_channel_id"
from  "l0karnatakabankdb"."htd_table_masked"  a
where date_parse((concat(split_part(cast(a."year" as varchar(4)),'.',1),'-',
split_part(cast(a."month" as varchar(2)),'.',1),'-',
split_part(cast(a."day" as varchar(2)),'.',1))), '%Y-%m-%d') between (date ('2023-08-31')) - interval '12' month and (date ('2023-08-31'))
),
tran_data_variables as (
Select
"cust_id",
sum(case WHEN "TRAN_RMKS" = 'UPI' AND "DELIVERY_CHANNEL_ID"= 'LCO' THEN 1 else 0 end) as "UPI_TXN",
sum(case when "PART_TRAN_TYPE" = 'D' and "TRAN_SUB_TYPE" = 'CI' then "TRAN_AMT" else 0 end) as "TOT_CUST_I_DEBIT_TXN_AMT",
--POS transaction 
sum(case WHEN "DELIVERY_CHANNEL_ID"='SWT' and "TRAN_PARTICULAR" like '%POS%' AND LENGTH("TRAN_RMKS") = 16 THEN 1 else 0 end) as "POS_TXN",
--IMPS Transactions
sum(case WHEN "DELIVERY_CHANNEL_ID"='LCO' and "TRAN_AMT" <> 5.9 and "TRAN_RMKS" = 'IMPS' THEN 1 else 0 end) as "IMPS_TXN",
count(distinct case when "DELIVERY_CHANNEL_ID" is null and "RCRE_USER_ID" like 'K%' then DATE("TRAN_DATE") else null end) as "TOT_BRANCH_VISITED_DAYS",
sum(case when "TRAN_SUB_TYPE" = 'CI' then 1 else 0 end) filter (where DATE("TRAN_DATE") BETWEEN DATE('2023-08-31') - interval '3' month and DATE('2023-08-31')) as "L3M_CUST_I_TXN",
sum(case when "TRAN_SUB_TYPE" = 'CI' then 1 else 0 end) as "TOT_CUST_I_TXN",
avg(case when "PART_TRAN_TYPE" = 'D' and "TRAN_SUB_TYPE" = 'CI' then "TRAN_AMT" else 0 end) as "AVG_CUST_I_DEBIT_TXN_AMT",
count(distinct (case when "DELIVERY_CHANNEL_ID" = 'SWT' and substring("TRAN_PARTICULAR",1,5) = 'ECOM-' and length("TRAN_RMKS") = 16 THEN CONCAT(to_char("TRAN_DATE" ,'yyyymmdd'), "TRAN_ID") ELSE NULL END)) AS "TOT_CI_ECOM_TXN"
from tran_data_base
group by "cust_id" 
),
cohort3_base as (
Select * from (
select *, row_number() over(partition by "cust_id") as rno from eligible_base_fnl 
)where rno = 1
),
prd_hld_var as (
Select a.cust_id,
count(a."schm_type") FILTER (where date(a."acct_opn_date") between Date('2023-08-31') - interval '12' month and date('2023-08-31')) as "TOTAL_OPEN_ACCTS_L12M"
from "l0karnatakabankdb"."general_acct_mast_table" a
join "l0karnatakabankdb"."sbca_mast_table" smt
on a."ACID" = smt."ACID" 
group by 1
),
avg_bal as (
Select "acid","eod_date","mab" as "avg_balance" from "l1karnatakabankdb"."mab_meb_incremental_master"
),
m1_avg as (
select a."ACID",
sum(case when date(b."eod_date") = (DATE('2023-08-31')) then b."avg_balance" else 0 end) as "M1_AVG" -- @
from eligible_base_fnl a
left join avg_bal b 
on a."ACID" = b."acid"
group by a."ACID"),
kpi_base as (
Select a.*,
date_diff ('year', DATE(a."cust_dob"), DATE('2023-08-31')) as "cust_age", -- @
d."occupation_desc" as "occupation_bkt", 
c."REGION_NAME" ,
d."cust_income", 
e."UPI_TXN", 
e."TOT_CUST_I_DEBIT_TXN_AMT",
e."POS_TXN", 
e."IMPS_TXN",
e."TOT_BRANCH_VISITED_DAYS", 
e."AVG_CUST_I_DEBIT_TXN_AMT",
e."TOT_CI_ECOM_TXN",
e."L3M_CUST_I_TXN",
e."TOT_CUST_I_TXN",
f."TOTAL_OPEN_ACCTS_L12M"
from cohort3_base a
left join "l0karnatakabankdb"."SERVICE_OUTLET_TABLE" c
on a."SOL_ID" = c."SOL_ID"
left join "l1karnatakabankdb"."customer_base" d 
on a."cust_id" = d."cust_id"
left join tran_data_variables e
on  a."cust_id" = e."cust_id"
left join prd_hld_var f 
on a."cust_id" = f."cust_id"
),
kpi_new_base as (
select a.*, b."M1_AVG" from kpi_base a left join m1_avg b on a."ACID" = b."ACID" )
,
kpi_new_base_final as (
Select cust_id,acid,sol_id,cust_age,occupation_bkt,region_name,cust_income,upi_txn,tot_cust_i_debit_txn_amt,imps_txn,pos_txn,tot_branch_visited_days,avg_cust_i_debit_txn_amt,tot_ci_ecom_txn,l3m_cust_i_txn,tot_cust_i_txn,total_open_accts_l12m,m1_avg from kpi_new_base
),
reg_base_dep as (
Select * from (
Select *, row_number() over(partition by user_id) as rno from "l0karnatakabankdb"."users" where "status" in ('R','A','B','L')) where rno = 1 
),
activated_base_dep as (
Select * from "l0karnatakabankdb"."mobileusershist" where "change_sl" = 1
)
select *, 
case when (date(reg_date) > date('2023-08-31') and date(reg_date) <= date('2024-02-29')) 
and activated_date is not null
then 1
else 0 end as "DEPVAR"
from (
Select a.*, b."cr_on" as reg_date, c.change_date as activated_date
from kpi_new_base_final a -- This table name has to be changed to base table
left join reg_base_dep b
on a.cust_id = lpad(trim(b.user_id),9,'0')
left join activated_base_dep c
on a.cust_id = lpad(trim(c.user_id),9,'0')
)

