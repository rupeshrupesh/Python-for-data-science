import sys
import subprocess
subprocess.call(['pip3','install','pandas==2.0.3','xgboost==1.7.5','joblib==1.2.0','ydata-profiling'])
from pyathena import connect
import pandas as pd
import numpy as np
import joblib
import pickle
from xgboost import XGBClassifier
from sklearn.preprocessing import OneHotEncoder
from ydata_profiling import ProfileReport
import scipy.stats.stats as stats
from datetime import datetime, date, timedelta
pd.set_option('display.max_colwidth',None)
pd.set_option('display.max_columns',None)
pd.set_option('display.max_rows',None)
pd.set_option('display.float_format', lambda x: '%.3f' % x)

print("1. Loading Packages")
import boto3
s3 = boto3.client('s3')

import sys
index = sys.argv.index('--s3_path')
s3_path = sys.argv[index+1]
print(s3_path)
my_json = pd.read_json(s3_path)

l0_bucket = my_json.loc["l0-bucket"]["buckets"]
l1_bucket = my_json.loc["l1-bucket"]["buckets"]
l2_bucket = my_json.loc["l2-bucket"]["buckets"]
l2_sub_folder = my_json.loc["l2-sub-folder"]["buckets"]

print(l2_bucket)

bucket_name = f'{l2_bucket}'
l2_sub_folder = f'{l2_sub_folder}'
file_key = '/Fixed_deposits_use_cases/FD_Cross_sell_model/model_pickle_file/Fd_cross_sell_xgb_model.pkl'

if len(l2_sub_folder)>0:
    final_path = l2_sub_folder+file_key
else:
    final_path = file_key

print(final_path)
print(bucket_name)

s3.download_file(bucket_name,final_path,'xgb.pkl')
xgb = joblib.load('xgb.pkl')
print("Model Loading Successful")

l2_bucket = l2_bucket + '/' + l2_sub_folder

print("2. Loading Data")
vars = pd.read_parquet(f"s3://{l2_bucket}/Fixed_deposits_use_cases/FD_Cross_sell_model/model_data_preparation_files/SBA_Non_Indiviual/")

print(vars.columns)
print(vars.head(5))
print(vars.shape)

#Remove fuplicate if any
vars.drop_duplicates(inplace=True)
print(vars.shape)

#Convert column names to lower case
vars.columns = vars.columns.str.lower()

#Convert to right data types
#vars['amt_booked'] = vars['amt_booked'].astype('float')
vars['m1_avg'] = vars['m1_avg'].astype('float')
vars['m2_avg'] = vars['m2_avg'].astype('float')
vars['m3_avg'] = vars['m3_avg'].astype('float')
vars['m4_avg'] = vars['m4_avg'].astype('float')
vars['m5_avg'] = vars['m5_avg'].astype('float')
vars['m6_avg'] = vars['m6_avg'].astype('float')
vars['last_m12_avg'] = vars['last_m12_avg'].astype('float')
vars['age'] = vars['age'].fillna(18).astype('int')
vars['mb_no_of_td_roi_inquiries_1months'] = vars['mb_no_of_td_roi_inquiries_1months'].astype('int')
vars['mb_no_of_td_roi_inquiries_3months'] = vars['mb_no_of_td_roi_inquiries_3months'].astype('int')
vars['bought_fd'] = vars['bought_fd'].astype('int')
vars['tot_branch_induced_db_amt_l12m'] = vars['tot_branch_induced_db_amt_l12m'].astype('float')
vars['tot_branch_induced_cr_amt_l12m'] = vars['tot_branch_induced_cr_amt_l12m'].astype('float')
vars['tot_ci_amt_l12m'] = vars['tot_ci_amt_l12m'].astype('float')
vars['amount_active_snapshot'] = vars['amount_active_snapshot'].astype('float')
vars['preffered_interest_rate_4yr'] = vars['preffered_interest_rate_4yr'].astype('float')
#ADGBT CALCULATION

vars['adgbt_l1m'] = np.where(vars['tot_ci_tran_days_l1m']>1,(((pd.to_datetime(vars['ci_ltd_l1m']) - pd.to_datetime(vars['ci_ftd_l1m'])).dt.days)/(vars['tot_ci_tran_days_l1m']-1)).round(),31)
vars['adgbt_l12m'] = np.where(vars['tot_ci_tran_days_l12m']>1,(((pd.to_datetime(vars['ci_ltd_l12m']) - pd.to_datetime(vars['ci_ftd_l12m'])).dt.days)/(vars['tot_ci_tran_days_l12m']-1)).round(),366)

#ONLY CREDIT - DEBIT TRANSACTIONS

#12 Month
vars['only_cr_l12m'] = np.where((vars['tot_ci_cr_tran_l12m'] > 0) & (vars['tot_ci_db_tran_l12m'] == 0),1,0)
vars['only_db_l12m'] = np.where((vars['tot_ci_cr_tran_l12m'] == 0) & (vars['tot_ci_db_tran_l12m'] > 0),1,0)

#CREDIT - DEBIT RATIO
vars['tot_ci_db_tran_l1m'] = vars['tot_ci_db_tran_l1m'].fillna(0)
vars['tot_ci_cr_tran_l1m'] = vars['tot_ci_cr_tran_l1m'].fillna(0)
vars['tot_ci_db_tran_l12m'] = vars['tot_ci_db_tran_l12m'].fillna(0)
vars['tot_ci_cr_tran_l12m'] = vars['tot_ci_cr_tran_l12m'].fillna(0)

vars['cr_dr_ratio_l1m']  = np.where(vars['tot_ci_db_tran_l1m'] > 0,vars['tot_ci_cr_tran_l1m']/vars['tot_ci_db_tran_l1m'],1) 
vars['cr_dr_ratio_l12m'] = np.where(vars['tot_ci_db_tran_l12m'] > 0,vars['tot_ci_cr_tran_l12m']/vars['tot_ci_db_tran_l12m'],1) 

#MAB RATIO
print(vars[vars['m1_avg']==0].shape)
vars['m1_avg'] = vars['m1_avg'].replace(0,0.01)
vars['last_m12_avg'] = vars['last_m12_avg'].replace(0,0.01)
vars['m1_m12_mab_ratio']  = vars['m1_avg']/vars['last_m12_avg']


##House Wifes
vars['house_wife_by_ocp_cd'] = np.where((vars['occupation_desc'] == 'HOUSE WIFE/HOME MAKER'),1,0)  

#Branch induced transactions variables

vars['tot_branch_induced_db_amt_l12m'] = vars['tot_branch_induced_db_amt_l12m'].fillna(0)
vars['tot_branch_induced_cr_amt_l12m'] = vars['tot_branch_induced_cr_amt_l12m'].fillna(0)
vars['tot_ci_amt_l12m'] = vars['tot_ci_amt_l12m'].fillna(0)

vars['total_tran_amt'] = vars['tot_branch_induced_db_amt_l12m']+vars['tot_branch_induced_cr_amt_l12m']+vars['tot_ci_amt_l12m']

vars['branch_to_total_tran_amt_ratio_l12m'] = np.where(vars['total_tran_amt']>0,round(vars['tot_branch_induced_db_amt_l12m'])/vars['total_tran_amt'],0)

##FIll NAs
vars['accounts_active_snapshot'] = vars['accounts_active_snapshot'].fillna(0)
vars['accounts_open_1months'] = vars['accounts_open_1months'].fillna(0)
vars['accounts_open_3months'] = vars['accounts_open_3months'].fillna(0)
vars['accounts_open_6months'] = vars['accounts_open_6months'].fillna(0)
vars['accounts_open_12months'] = vars['accounts_open_12months'].fillna(0)
vars['accounts_closed_1months'] = vars['accounts_closed_1months'].fillna(0)
vars['accounts_closed_3months'] = vars['accounts_closed_3months'].fillna(0)

#FD Variables
vars['accounts_renewed_snapshot_1month'] = vars['accounts_renewed_snapshot_1month'].fillna(0)
vars['accounts_renewed_snapshot_3months'] = vars['accounts_renewed_snapshot_3months'].fillna(0)

vars['amount_active_snapshot'] = vars['amount_active_snapshot'].fillna(0)
vars['renewed_fd_last_month'] = np.where(vars['accounts_renewed_snapshot_1month']>0,1,0)
vars['renewed_fd_last_quarter'] = np.where(vars['accounts_renewed_snapshot_3months']>0,1,0)
vars['opened_fd_last_month'] = np.where(vars['accounts_open_1months']>0,1,0)
vars['opened_fd_last_quarter'] = np.where(vars['accounts_open_3months']>0,1,0)
vars['closed_fd_last_month'] = np.where(vars['accounts_closed_1months']>1,1,0)
vars['closed_fd_last_quarter'] = np.where(vars['accounts_closed_3months']>1,1,0)
vars['opened_fd_in_last_3_to_12_months'] = np.where((vars['opened_fd_last_quarter'] == 0) & (vars['accounts_open_12months']>0),1,0)
vars['active_fd_deposit_amt_to_last_month_casa_ratio'] = vars['amount_active_snapshot']/vars['m1_avg']

###Service requests variable
vars['raised_td_roi_req_last_month'] = np.where(vars['mb_no_of_td_roi_inquiries_1months'] > 0,1,0)
vars['raised_td_roi_req_last_quarter'] = np.where(vars['mb_no_of_td_roi_inquiries_3months'] > 0,1,0)

vars['preffered_tenure_4yr'] = vars['preffered_tenure_4yr'].fillna('None')
vars['preffered_interest_rate_4yr'] = vars['preffered_interest_rate_4yr'].fillna(-1)

vars.drop(['cust_id1','ci_ftd_l1m','ci_ltd_l1m','ci_ftd_l12m','ci_ltd_l12m'],axis=1,inplace=True)

vars.drop(['m2_avg','m3_avg','m4_avg','m5_avg','m6_avg'],axis=1,inplace=True)

null_cols = vars.columns[vars.isnull().any()]
print(null_cols)

vars_int = vars.select_dtypes(include=['int','int64','float64'])
vars[vars_int.columns] = vars_int.fillna(0)

vars_int = vars.select_dtypes(include=['object'])
vars[vars_int.columns] = vars_int.fillna('Not available')

cat_cols = vars.drop(columns=["cust_id","cust_segment","sol_id","cust_type","mb_registered","ib_registered","occupation_desc","sub_category","parent_category"]).select_dtypes(include='object')

# perform one hot encoding on the categorical columns
one_hot_encoded = pd.get_dummies(cat_cols,drop_first=True)

# merge the one hot encoded columns with the original dataframe
vars = pd.concat([vars, one_hot_encoded], axis=1)

# drop the original categorical columns
vars = vars.drop(cat_cols.columns, axis=1)

vars['opened_fd_in_2_to_3_months'] = np.where((vars['opened_fd_last_quarter']==1) & (vars['opened_fd_last_month']==0),1,0)

vars['closed_fd_in_2_to_3_months'] = np.where((vars['closed_fd_last_quarter']==1) & (vars['closed_fd_last_month']==0),1,0)

vars['age'] = np.where(vars['age']>90,90,vars['age'])
vars['age'] = np.where(vars['age']<18,18,vars['age'])

print("Model dataset shape",vars.shape)

model_vars = vars[['age','preffered_interest_rate_4yr', 'm1_avg', 'has_locker', 'has_loan',\
                   'only_cr_l12m', 'only_db_l12m', 'cr_dr_ratio_l1m', 'cr_dr_ratio_l12m',\
                   'house_wife_by_ocp_cd', 'closed_fd_last_month', 'opened_fd_in_last_3_to_12_months',\
                   'renewed_fd_last_quarter', 'opened_fd_last_month',\
                   'active_fd_deposit_amt_to_last_month_casa_ratio', 'tot_ci_cr_tran_days_l1m',\
                   'branch_to_total_tran_amt_ratio_l12m', 'raised_td_roi_req_last_month',\
                   'raised_td_roi_req_last_quarter', 'adgbt_l1m', 'adgbt_l12m', 'm1_m12_mab_ratio',\
                   'region_name_BANGALORE', 'region_name_CHENNAI', 'region_name_DELHI', 'region_name_HUBLI',\
                   'region_name_HYDERABAD', 'region_name_KALABURGI', 'region_name_KOLKATA',\
                   'region_name_MANGALORE', 'region_name_MUMBAI', 'region_name_MYSORE', 'region_name_SHIMOGA',\
                   'region_name_TUMAKURU', 'region_name_UDUPI', 'dp_code_RURAL', 'dp_code_SURBAN',\
                   'dp_code_URBAN', 'preffered_tenure_4yr_181 to 364 days',\
                   'preffered_tenure_4yr_2 to 3 years', 'preffered_tenure_4yr_3 to 5 years',\
                   'preffered_tenure_4yr_5 to 10 years', 'preffered_tenure_4yr_7 to 90 days',\
                   'preffered_tenure_4yr_91 to 180 days', 'opened_fd_in_2_to_3_months',\
                   'closed_fd_in_2_to_3_months']].copy()

#Create and Save profiling output to S3 location
profile_report = ProfileReport(model_vars,title='Data Quality Report',explorative=False,minimal=True)
profile_report.to_file("Model_Profiling_report_ETB_Above_5k.html")
s3.upload_file("Model_Profiling_report_ETB_Above_5k.html",bucket_name,"Fixed_deposits_use_cases/FD_Cross_sell_model/Model_data_profiling/Model_Profiling_report_ETB_Above_5k.html")

talking_points = vars[['cust_id','sol_id','mb_registered','ib_registered','last_m12_avg','occupation_desc','sub_category','parent_category','no_of_loans','no_of_casa_acct','accounts_active_snapshot']]

print("Model dataset shape: ",model_vars.shape)
print("Talking points shape: ",talking_points.shape)

y_pred_proba = xgb.predict_proba(model_vars)[:, 1]
model_vars['Predictions'] = y_pred_proba.tolist()
model_output = pd.concat([model_vars,talking_points],axis=1)

model_output.sort_values(by='Predictions',inplace=True,ascending=False)
model_output['Decile']=100-pd.qcut(model_output.Predictions,100,labels=False,duplicates = 'drop')
model_output['Decile_Rank'] = model_output['Decile'] - (100 - model_output['Decile'].nunique())

#Write score to S3 location
model_output[['cust_id','Predictions','Decile_Rank']].to_csv(f's3://{l2_bucket}/NBP/Model_Input_Files/FD_CrossSell_SBA_Non_Ind.csv',index=False)

model_target_deciles = model_output[(model_output.Decile_Rank >=1) & (model_output.Decile_Rank <=15)].copy()

model_target_deciles['has_locker'] = np.where(model_target_deciles['has_locker']==1,'Yes','No')
model_target_deciles['raised_td_roi_req_last_quarter'] = np.where(model_target_deciles['raised_td_roi_req_last_quarter']==1,'Yes','No')
model_target_deciles['opened_fd_in_last_3_to_12_months'] = np.where(model_target_deciles['opened_fd_in_last_3_to_12_months']==1,'Yes','No')

columns = ['unique_id','lead_source', 'campaign_name', 'campaign_type', 'base_product','crosssell_product', 'customer_id',
                'sol_id','empid','channel','campaign_id', 'campaign_start_date', 'campaign_end_date','mb_registered',
       'ib_registered','additional_information_1', 'additional_information_2','additional_information_3', 'additional_information_4',
       'additional_information_5', 'additional_information_6','additional_information_7', 'additional_information_8',
       'additional_information_9', 'additional_information_10', 'event_date','account_nbr','balance','due_date',
       'payment_link', 'dm_flag', 'dm_date', 'lead_status', 'lead_status_2','disposition_description_1',
           'disposition_description_2','disposition_description_3','disposition_description_4','disposition_description_5',
           'disposition_timestamp','Control','current_date','lead_id','manage_portfolio','target_assignee']

leads = pd.DataFrame(columns=columns)

leads['customer_id']=model_target_deciles['cust_id']
leads['sol_id']=model_target_deciles['sol_id']

#Assign top 1 percentile leads to CC [Changes made from 02 May]
leads['channel']=np.where((model_target_deciles['Decile_Rank'] >1) & (model_target_deciles['Decile_Rank'] <=5),'BB','Digital')
leads['channel']=np.where(model_target_deciles['Decile_Rank']==1,'CC',leads['channel'])

leads['campaign_id'] = 'CAMFD0001'

leads['lead_source'] = 'Analytics'
leads['campaign_name'] = 'FD Cross Sell'
leads['campaign_type'] = 'High Propensity of FD cross-sell'
leads['base_product'] = 'SA'
leads['crosssell_product'] = 'FD'

leads['campaign_start_date']=date.today()
leads['campaign_end_date']=date.today() + timedelta(days=90)

leads['mb_registered']=model_target_deciles['mb_registered']
leads['ib_registered']=model_target_deciles['ib_registered']

leads['additional_information_1']="Pitch term deposit to this active savings bank customer as the customer has high propensity to open an TD account in next one month" 
leads['additional_information_2']="Customer is an Non-Indiviual"
leads['additional_information_3']=""
leads['additional_information_4']="Last Month's average Balance in savings account(s) : " + model_target_deciles['m1_avg'].round().astype('str')
leads['additional_information_5']="Number of Active Savings account(s) : " + model_target_deciles['no_of_casa_acct'].round().astype('str')
#leads['additional_information_5']=np.where(model_target_deciles['Decile_Rank'] <=5,'Very High Decile','High Decile')
leads['additional_information_6']="Number of Active loan account(s) : " + model_target_deciles['no_of_loans'].round().astype('str')
leads['additional_information_7']="Customer Segment : " + model_target_deciles['parent_category'].astype('str')
leads['additional_information_8']="Number of Active Term deposit account(s) : " + model_target_deciles['accounts_active_snapshot'].round().astype('str')
leads['additional_information_9']="Last 12 months average savings account balance: " + model_target_deciles['last_m12_avg'].round().astype('str')
leads['additional_information_10']="Raised TD ROI service request last quarter: " + model_target_deciles['raised_td_roi_req_last_quarter']
leads['Control'] = np.where(model_target_deciles['cust_id'].str.endswith('9'),'Y','N')
leads['Control'].value_counts()
leads['event_date'] = date.today() + timedelta(days=1)
leads['current_date'] = date.today()
print(leads['channel'].value_counts())

#Updating managed portfolio related leads as blanks
leads['lead_id'] = ""
print(leads.head())

#Merge with RM table to flag these leads as 'YES'
# managed_port = pd.read_parquet(f"s3://{l2_bucket}/Bh_Lead_Portfolio/managed_portfolio_fact_table")
# print(managed_port.head())
# print(managed_port.columns)

# leads['manage_portfolio'] = leads['customer_id'].isin(managed_port['cust_id']).apply(lambda x: 'YES' if x else '')
# print(leads['manage_portfolio'].value_counts())


#Logic updated on 21 May 2024. Input table read in SQL SBA pipeline
managed_port = pd.read_parquet(f"s3://{l2_bucket}/Fixed_deposits_use_cases/FD_Cross_sell_model/model_data_preparation_files/managed_port/")

leads['manage_portfolio'] = leads['customer_id'].isin(managed_port['cust_id']).apply(lambda x: 'YES' if x else '')
print(leads['manage_portfolio'].value_counts())

print(len(leads))
print(leads.columns)
leads = pd.merge(leads, managed_port[['cust_id','emp_id']], how = 'left', left_on = 'customer_id', right_on = 'cust_id')
print(len(leads))
leads['target_assignee'] = leads['emp_id']
leads.drop(['emp_id','cust_id'], axis=1,inplace=True)
print(leads['target_assignee'].value_counts())
print(leads.columns)

'''For leads that are sent for branch calling, do the following:

Split leads to be sent to branches into 4 random buckets** This exercise is to get the experiment with channels for next 6 months and present mult-channel orchestration findings to business teams

Bucket 1: Branch calling

Bucket 2: Branch calling + Send SMS

Bucket 3: Branch calling + Send Email

Bucket 4: Branch calling + Send Email + Send SMS

Except Bucket 1, append other dataframe to orginal dataframe (for branches) after updating their respective channel orchestrations. (Bucket 4 will be appended twice with SMS & email respectively)
'''

'''August 8th 2024: BB + DIgital removed: 1=CC; 2-5=BB; 6-15=DIgital)'''

leads_br = leads[leads['channel']=='BB'].copy()
# np.random.seed(42)
# shuffled_leads_br = leads_br.sample(frac=1)
# split_size = len(shuffled_leads_br)//4

# leads_br_set1 = shuffled_leads_br.iloc[:split_size].copy()
# leads_br_set2 = shuffled_leads_br.iloc[split_size:2*split_size].copy()
# leads_br_set3 = shuffled_leads_br.iloc[2*split_size:3*split_size].copy()
# leads_br_set4 = shuffled_leads_br.iloc[3*split_size:].copy()

# leads_br_set4_2 = leads_br_set4.copy()

# leads_br_set2['channel'] = 'SMS'
# leads_br_set3['channel'] = 'EMAIL'

# leads_br_set4['channel'] = 'SMS'
# leads_br_set4_2['channel'] = 'EMAIL'

'''
For leads that are sent to digital channels, do the following:

Split leads to be sent to branches into 4 random buckets** This exercise is to get the experiment with channels for next 6 months and present mult-channel orchestration findings to business teams

Bucket 1: Send SMS

Bucket 2: Send Email

Bucket 3: Send Email + Send SMS

Append other bucketed dataframes to orginal dataframe (for digital) after updating their respective channel orchestrations. (Bucket 3 will be appended twice with SMS & email respectively)
'''

leads_digital = leads[leads['channel']=='Digital'].copy()
np.random.seed(42)
shuffled_leads_digital = leads_digital.sample(frac=1)
split_size = len(shuffled_leads_digital)//3

leads_digital_set1 = shuffled_leads_digital.iloc[:split_size].copy()
leads_digital_set2 = shuffled_leads_digital.iloc[split_size:2*split_size].copy()
leads_digital_set3 = shuffled_leads_digital.iloc[2*split_size:].copy()

leads_digital_set3_2 = leads_digital_set3.copy()

leads_digital_set1['channel'] = 'SMS'
leads_digital_set2['channel'] = 'EMAIL'

leads_digital_set3['channel'] = 'SMS'
leads_digital_set3_2['channel'] = 'EMAIL'

#Append to Branch dataframe: Old straget till Feb 2024
# leads_final = pd.concat([leads_br,leads_br_set2,leads_br_set3,leads_br_set4,leads_br_set4_2,\
#                             leads_digital_set1,leads_digital_set2,leads_digital_set3,\
#                             leads_digital_set3_2],axis=0)

#Updated strategy from March 2024
leads_cc = leads[leads['channel']=='CC'].copy()
leads_cc_sms = leads_cc.copy()
leads_cc_sms['channel']='SMS'

# leads_final = pd.concat([leads_cc,leads_cc_sms,leads_br_set1,leads_br_set2,leads_br_set3,leads_br_set4,leads_br_set4_2,\
#                             leads_digital_set1,leads_digital_set2,leads_digital_set3,\
#                             leads_digital_set3_2],axis=0)


#Updated on Aug 3 2024
leads_final = pd.concat([leads_cc,leads_cc_sms,leads_br,leads_digital_set1,leads_digital_set2, leads_digital_set3, leads_digital_set3_2],axis=0)
                            
leads_final['channel'].value_counts()

'''
Remove duplicate communications [3 months history]
For every month, we need to check if customer was targeted in last 3 months through Branches. 
If yes then such customer should be ignored for the current month lead generation process. 
'''
# Read history response tables:
crm_hist = pd.read_parquet(f"s3://{l2_bucket}/Fixed_deposits_use_cases/FD_Cross_sell_model/model_data_preparation_files/crm_history/")
crm_hist = crm_hist.drop_duplicates()

#Before
print(leads_final['channel'].value_counts())

# Remove all overlapping customers in current month Leads list
leads_final = leads_final[~(leads_final['customer_id'].isin(crm_hist['customer_id']) &\
               leads_final['channel'].isin(crm_hist['channel']))]

#After
print(leads_final['channel'].value_counts())

leads_final.to_csv(f's3://{l2_bucket}/Fixed_deposits_use_cases/FD_Cross_sell_model/model_output_files/SBA_Non_Indiviuals.csv',index=False,header=False)