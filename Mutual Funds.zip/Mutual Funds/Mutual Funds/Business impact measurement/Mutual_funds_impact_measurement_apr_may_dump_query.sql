with km_ctl as
(
SELECT
'fisdom_lumpsum' as source,
cust_id,
amount as amount,
case when cust_id is not null then amount end as amount_with_cust_id
FROM "l1karnatakabankdb"."fisdom_mutual_funds_lumpsum_purchase_transactions" 
where year(investment_date) = year(date('2024-06-01')) and month(investment_date) = month(date('2024-06-01'))
union all
SELECT
'fisdom_sip' as source,
cust_id,
sip_amount as amount,
case when cust_id is not null then sip_amount end as amount_with_cust_id
FROM "l1karnatakabankdb"."fisdom_mutual_funds_sip_transactions" 
where year(sip_start_date) = year(date('2024-06-01')) and month(sip_start_date) = month(date('2024-06-01'))
union all
select
'kfintech' as source,
cust_id,
td_amt as amount,
case when cust_id is not null then td_amt end as amount_with_cust_id
FROM "l1karnatakabankdb"."kfintech_amc_mf_data"
where td_purred = 'P'
and year(td_trdt) = year(date('2024-06-01')) and month(td_trdt) = month(date('2024-06-01'))
union all
select
'CAMS' as source,
cust_id,
amount as amount,
case when cust_id is not null then amount end as amount_with_cust_id 
FROM "l1karnatakabankdb"."cams_amc_mf_data"
where trxn_mode = 'N'
and year(trad_date) = year(date('2024-06-01')) and month(trad_date) = month(date('2024-06-01'))
),
campaign_base as
(
SELECT distinct customer_id,control FROM "l2karnatakabankdb"."acoe_crm_leads_input_history"
where 
substr(unique_id,1,6) in (substr('2024-06-01',1,4) || substr('2024-06-01',6,2))
and campaign_name = 'Mutual Funds Cross Sell' 
)
select customer_id,control,sum(amount_with_cust_id) 
from campaign_base inner join km_ctl on campaign_base.customer_id = km_ctl.cust_id 
where amount_with_cust_id < 10000000
group by 1,2;