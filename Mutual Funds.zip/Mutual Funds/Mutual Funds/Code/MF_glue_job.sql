import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job

sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)

args = getResolvedOptions(sys.argv,["s3_path"])
s3_path = args['s3_path']
 
dataFrame = spark.read\
    .option("multiline", "true")\
    .json(s3_path)

l0_bucket = dataFrame.select("buckets.l0-bucket").collect()[0][0]
l1_bucket = dataFrame.select("buckets.l1-bucket").collect()[0][0]
l2_bucket = dataFrame.select("buckets.l2-bucket").collect()[0][0]
l2_sub_folder = dataFrame.select("buckets.l2-sub-folder").collect()[0][0]
print(l2_bucket)
l2_bucket = l2_bucket + '/' + l2_sub_folder
print(l2_bucket)

l0_database =  dataFrame.select("databases.l0-database").collect()[0][0]
l1_database =  dataFrame.select("databases.l1-database").collect()[0][0]
l2_database =  dataFrame.select("databases.l2-database").collect()[0][0]

spark.sql(f"""SELECT cust_id,current_date AS cohort,sol_id,acct_opn_date,cust_gender,occupation_desc,region_name,dp_code,
case when cust_constitution_code = '01' then 1 end as is_indiviual,
cast(round(date_diff('day',date(cust_dob),current_date)/365.25,0) as int) AS age,
ROW_NUMBER() OVER (PARTITION BY cust_id ORDER BY acct_opn_date desc) AS sol_rnk
FROM l1karnatakabankdb.casa_master
INNER JOIN l1karnatakabankdb.customer_base USING (cust_id)
LEFT JOIN l0karnatakabankstg.service_outlet_table USING (sol_id)
WHERE (acct_cls_date is NULL OR acct_cls_date > last_day_of_month(current_date))  
AND acc_status = 'A' AND ignore_flag = 'N'
AND schm_type IN ('SBA','CAA') AND cust_constitution_code IN ('01','11')
AND cust_nationality = 'N'
AND acct_opn_date <= date_trunc('Month',date_add('month',-6,current_date))
AND cast(round(date_diff('day',date(cust_dob),current_date)/365.25,0) as int) BETWEEN 21 AND 65""").createOrReplaceTempView("init_base")

spark.sql(f"""SELECT cust_id,cohort,sol_id,cust_gender,occupation_desc,region_name,dp_code,age
FROM init_base WHERE sol_rnk = 1 """).createOrReplaceTempView("base")

spark.sql(f"""SELECT cust_id,
sum(CASE WHEN schm_type = 'SBA' THEN mab END) AS l1m_sba_bal,
sum(CASE WHEN schm_type = 'CAA' THEN mab END) AS l1m_caa_bal,
sum(CASE WHEN schm_type = 'TDA' THEN meb END) AS l1m_tda_bal
FROM base INNER JOIN l1karnatakabankdb.mab_meb_incremental_master USING (cust_id) 
WHERE YEAR = extract(year FROM (date_trunc('month',current_date) - INTERVAL '1' DAY)) 
AND MONTH = extract(MONTH FROM (date_trunc('month',current_date) - INTERVAL '1' DAY))
GROUP BY 1""").createOrReplaceTempView("l1m_balance")

spark.sql(f"""SELECT cust_id,
sum(CASE WHEN schm_type = 'SBA' THEN mab END) AS l3m_sba_bal,
sum(CASE WHEN schm_type = 'CAA' THEN mab END) AS l3m_caa_bal,
sum(CASE WHEN schm_type = 'TDA' THEN meb END) AS l3m_tda_bal
FROM base INNER JOIN l1karnatakabankdb.mab_meb_incremental_master USING (cust_id) 
WHERE YEAR = extract(year FROM (date_trunc('month',current_date) - INTERVAL '2' MONTH - INTERVAL '1' DAY)) 
AND MONTH = extract(MONTH FROM (date_trunc('month',current_date) - INTERVAL '2' MONTH - INTERVAL '1' DAY))
GROUP BY 1""").createOrReplaceTempView("l3m_balance")

spark.sql(f"""SELECT cust_id,
sum(CASE WHEN schm_type = 'SBA' THEN mab END) AS l6m_sba_bal,
sum(CASE WHEN schm_type = 'CAA' THEN mab END) AS l6m_caa_bal,
sum(CASE WHEN schm_type = 'TDA' THEN meb END) AS l6m_tda_bal
FROM base INNER JOIN l1karnatakabankdb.mab_meb_incremental_master USING (cust_id) 
WHERE YEAR = extract(year FROM (date_trunc('month',current_date) - INTERVAL '5' MONTH - INTERVAL '1' DAY)) 
AND MONTH = extract(MONTH FROM (date_trunc('month',current_date) - INTERVAL '5' MONTH - INTERVAL '1' DAY))
GROUP BY 1""").createOrReplaceTempView("l6m_balance")

spark.sql(f"""SELECT cust_id,
count(CASE WHEN ACCT_OPN_DATE between (date_trunc('month',current_date) - interval '6' month) 
and date_trunc('month',current_date) - interval '1' day THEN 1 END) AS l6m_fd_opended
FROM base INNER JOIN l1karnatakabankdb.fd_base_table USING (cust_id)
GROUP BY 1""").createOrReplaceTempView("td_vars")

spark.sql(f"""SELECT cust_id,
count(DISTINCT((CASE WHEN date(login_datetime) between (date_trunc('month',current_date) - interval '3' month) and date_trunc('month',current_date) - interval '1' day
THEN (DATE(login_datetime)) END))) AS l3m_no_of_logins
FROM base a inner JOIN l0karnatakabankstg.usersloginhist b ON a.cust_id = b.user_id
GROUP BY 1""").createOrReplaceTempView("mb_logins")


spark.sql(f"""SELECT cust_id,
count(case when part_tran_type = 'C' then 1 end) as l6m_credit_tran,
count(case when part_tran_type = 'D' then 1 end) as l6m_debit_tran,
count(distinct(case when part_tran_type = 'C' then tran_date end)) as l6m_credit_days,
count(distinct(case when part_tran_type = 'D' then tran_date end)) as l6m_debit_days,
count(distinct(tran_date)) as l6m_tran_days,
sum(case when part_tran_type = 'C' then tran_amt end) as l6m_credit_tran_amt,
sum(case when part_tran_type = 'D' then tran_amt end) as l6m_debit_tran_amt,
count(case when part_tran_type = 'D' AND payment_type IN ('POS- Debit Card','ECOM-Debit Card') then 1 end) as l6m_debit_card_spend_tran,
sum(case when part_tran_type = 'D' AND payment_type  IN ('POS- Debit Card','ECOM-Debit Card') then tran_amt end) as l6m_debit_card_spend_amt,
count(case when part_tran_type = 'D' AND payment_type  IN ('Balance Inquiry Charges') then 1 end) as l6m_balance_inquiry_tran,
count(case when part_tran_type = 'D' AND payment_type2 IN ('Utility Bills') then 1 end) as l6m_utlility_bill_tran,
count(case when part_tran_type = 'D' AND payment_type2 IN ('Insurance') then 1 end) as l6m_insurance_premium_tran,
count(case when part_tran_type = 'D' AND purpose IN ('AMAZON/FLIPKART') then 1 end) as l6m_ecommerce_spends_tran,
sum(case when part_tran_type = 'D' AND purpose IN ('AMAZON/FLIPKART') then tran_amt end) as l6m_ecommerce_spends_amt
FROM base INNER JOIN l2karnatakabankdb.transaction_master USING (cust_id)
where include/exclude = 'Y'
and 
AND
(
(YEAR = (extract(year from date_trunc('month',current_date) - INTERVAL '6' month)) AND MONTH >= (extract(month from date_trunc('month',current_date) - INTERVAL '6' month)))
OR
(YEAR = (extract(year from date_trunc('month',current_date))) AND MONTH <= (extract(month from date_trunc('month',current_date) - INTERVAL '1' month)))
)
and tran_crncy_code = 'INR' and schm_type in ('SBA','CAA')
group by 1""").createOrReplaceTempView("l6m_tran")

spark.sql(f"""select cust_id,sub_category,parent_category from base inner join l2karnatakabankdb.savings_customer_segmentation using (cust_id)""").createOrReplaceTempView("cust_segment")

spark.sql(f"""SELECT distinct cust_id,1 as mb_registered FROM l0karnatakabankstg.users a inner join base b on a.user_id = b.cust_id  
where status in ('R','A','B','L')""").createOrReplaceTempView("mb_registered")

spark.sql(f"""SELECT distinct cust_id,1 as ib_registered FROM l0karnatakabankstg.facility_version_table  inner join base using (cust_id)""").createOrReplaceTempView("ib_registered")

s3://analytics-karnatakabank-bucket/Analytics_tables/mutual_funds_cross_sell/production/

spark.sql(f"""SELECT *
FROM base 
LEFT JOIN l1m_balance USING (cust_id)
LEFT JOIN l6m_balance USING (cust_id)
LEFT JOIN l3m_balance USING (cust_id)
LEFT JOIN td_vars USING (cust_id)
LEFT JOIN on_us_insurance USING (cust_id)
LEFT JOIN on_us_mf USING (cust_id)
LEFT JOIN mb_logins USING (cust_id)
LEFT JOIN l6m_tran USING (cust_id)
LEFT JOIN on_us_events USING (cust_id)
LEFT JOIN off_us_events USING (cust_id)
LEFT JOIN cust_segment USING (cust_id)
LEFT JOIN mb_registered USING (cust_id)
LEFT JOIN ib_registered USING (cust_id)
where (coalesce(l1m_sba_bal,0) + coalesce(l1m_caa_bal,0)) > 500
and (coalesce(l6m_credit_tran,0) + coalesce(l6m_debit_tran,0)) > 0""").write.mode("overwrite").format("parquet").save("s3://analytics-karnatakabank-bucket/Analytics_tables/mutual_funds_cross_sell/production/")

job.commit()