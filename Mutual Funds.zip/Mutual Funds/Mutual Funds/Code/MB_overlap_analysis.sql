select mb_eligible_flag,mb_registered_flag,count(distinct customer_id) 
FROM "l2karnatakabankdb"."acoe_crm_leads_input_history" inner join "l2karnatakabankdb"."ded_digital_master_table" 
on customer_id = cust_id
where campaign_name in ('Mutual Funds Cross Sell') and unique_id like '202404%'
group by 1,2;

with base as
(
SELECT 
customer_id,
count(distinct campaign_name) as campaign,
count(distinct(case when campaign_name = 'Mutual Funds Cross Sell' and mb_registered = 'Y' then mb_registered else null end)) as registered
FROM "l2karnatakabankdb"."acoe_crm_leads_input_history" 
where campaign_name in ('Mobile Banking Registration','Mutual Funds Cross Sell') and unique_id like '202404%'
and customer_id not in (select distinct cust_id from "l2karnatakabankdb"."ded_digital_master_table" where mb_registered_flag = 0)
group by 1
having count(distinct campaign_name) = 2
)
select count(1) from base;