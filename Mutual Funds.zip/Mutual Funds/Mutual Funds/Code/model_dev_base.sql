CREATE TABLE IF NOT EXISTS analytics_db.mf_model_dev_base
WITH (format='PARQUET', external_location='s3://analytics-karnatakabank-bucket/Analytics_tables/mutual_funds_cross_sell/cohorts/mf_model_dev_base') AS
select * from analytics_db.mf_cohort_oct22
where (coalesce(l1m_sba_bal,0) + coalesce(l1m_caa_bal,0)) > 500
and (coalesce(l6m_credit_tran,0) + coalesce(l6m_debit_tran,0)) > 0 
union all
select * from analytics_db.mf_cohort_nov22
where (coalesce(l1m_sba_bal,0) + coalesce(l1m_caa_bal,0)) > 500
and (coalesce(l6m_credit_tran,0) + coalesce(l6m_debit_tran,0)) > 0 
union all
select * from analytics_db.mf_cohort_dec22
where (coalesce(l1m_sba_bal,0) + coalesce(l1m_caa_bal,0)) > 500
and (coalesce(l6m_credit_tran,0) + coalesce(l6m_debit_tran,0)) > 0 
union all
select * from analytics_db.mf_cohort_jan23
where (coalesce(l1m_sba_bal,0) + coalesce(l1m_caa_bal,0)) > 500
and (coalesce(l6m_credit_tran,0) + coalesce(l6m_debit_tran,0)) > 0 
union all
select * from analytics_db.mf_cohort_feb23
where (coalesce(l1m_sba_bal,0) + coalesce(l1m_caa_bal,0)) > 500
and (coalesce(l6m_credit_tran,0) + coalesce(l6m_debit_tran,0)) > 0 
union all
select * from analytics_db.mf_cohort_mar23
where (coalesce(l1m_sba_bal,0) + coalesce(l1m_caa_bal,0)) > 500
and (coalesce(l6m_credit_tran,0) + coalesce(l6m_debit_tran,0)) > 0 
union all
select * from analytics_db.mf_cohort_apr23
where (coalesce(l1m_sba_bal,0) + coalesce(l1m_caa_bal,0)) > 500
and (coalesce(l6m_credit_tran,0) + coalesce(l6m_debit_tran,0)) > 0 
union all
select * from analytics_db.mf_cohort_may23
where (coalesce(l1m_sba_bal,0) + coalesce(l1m_caa_bal,0)) > 500
and (coalesce(l6m_credit_tran,0) + coalesce(l6m_debit_tran,0)) > 0 
union all
select * from analytics_db.mf_cohort_jun23
where (coalesce(l1m_sba_bal,0) + coalesce(l1m_caa_bal,0)) > 500
and (coalesce(l6m_credit_tran,0) + coalesce(l6m_debit_tran,0)) > 0 
union all
select * from analytics_db.mf_cohort_jul23
where (coalesce(l1m_sba_bal,0) + coalesce(l1m_caa_bal,0)) > 500
and (coalesce(l6m_credit_tran,0) + coalesce(l6m_debit_tran,0)) > 0 
union all
select * from analytics_db.mf_cohort_aug23
where (coalesce(l1m_sba_bal,0) + coalesce(l1m_caa_bal,0)) > 500
and (coalesce(l6m_credit_tran,0) + coalesce(l6m_debit_tran,0)) > 0 
union all
select * from analytics_db.mf_cohort_sep23
where (coalesce(l1m_sba_bal,0) + coalesce(l1m_caa_bal,0)) > 500
and (coalesce(l6m_credit_tran,0) + coalesce(l6m_debit_tran,0)) > 0 
union all
select * from analytics_db.mf_cohort_oct23
where (coalesce(l1m_sba_bal,0) + coalesce(l1m_caa_bal,0)) > 500
and (coalesce(l6m_credit_tran,0) + coalesce(l6m_debit_tran,0)) > 0 
union all
select * from analytics_db.mf_cohort_nov23
where (coalesce(l1m_sba_bal,0) + coalesce(l1m_caa_bal,0)) > 500
and (coalesce(l6m_credit_tran,0) + coalesce(l6m_debit_tran,0)) > 0