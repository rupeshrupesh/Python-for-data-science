CREATE TABLE IF NOT EXISTS analytics_db.mf_cohort_event_rate_check
WITH (format='PARQUET', external_location='s3://analytics-karnatakabank-bucket/Analytics_tables/mutual_funds_cross_sell/cohorts/mf_cohort_event_rate_check') AS
select * from analytics_db.mf_cohort_apr22
union all
select * from analytics_db.mf_cohort_may22
union all
select * from analytics_db.mf_cohort_jun22
union all
select * from analytics_db.mf_cohort_jul22
union all
select * from analytics_db.mf_cohort_aug22
union all
select * from analytics_db.mf_cohort_sep22
union all
select * from analytics_db.mf_cohort_oct22
union all
select * from analytics_db.mf_cohort_nov22
union all
select * from analytics_db.mf_cohort_dec22
union all
select * from analytics_db.mf_cohort_jan23
union all
select * from analytics_db.mf_cohort_feb23
union all
select * from analytics_db.mf_cohort_mar23
union all
select * from analytics_db.mf_cohort_apr23
union all
select * from analytics_db.mf_cohort_may23
union all
select * from analytics_db.mf_cohort_jun23
union all
select * from analytics_db.mf_cohort_jul23
union all
select * from analytics_db.mf_cohort_aug23
union all
select * from analytics_db.mf_cohort_sep23
union all
select * from analytics_db.mf_cohort_oct23
union all
select * from analytics_db.mf_cohort_nov23
union all
select * from analytics_db.mf_cohort_dec23


select cohort,
count(1),count(distinct cust_id),
count(y_var_1),count(y_var_2) 
from analytics_db.mf_cohort_event_rate_check 
where (coalesce(l1m_sba_bal,0) + coalesce(l1m_caa_bal,0)) > 500
group by 1;

