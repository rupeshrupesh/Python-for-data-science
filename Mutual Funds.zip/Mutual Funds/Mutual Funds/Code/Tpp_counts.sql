--- Customer level Dump
SELECT event_date,sol_id,customer_id,lead_status,lead_status_2,disposition_description_1,lead_id
FROM "l2karnatakabankdb"."acoe_crm_leads_prod" 
where campaign_name in ('Life Insurance Cross Sell')
and channel = 'BB';

SELECT campaign_start_date,sol_id,customer_id,lead_status,lead_status_2,disposition_description_1,lead_id
FROM "l2karnatakabankdb"."acoe_crm_leads_prod" 
where campaign_name in ('General Insurance Cross-Sell')
and channel = 'BB';


SELECT event_date,sol_id,customer_id,lead_status,lead_status_2,disposition_description_1,lead_id
FROM "l2karnatakabankdb"."acoe_crm_leads_prod" 
where campaign_name in ('Life Insurance Cross Sell')
and channel in ('EMAIL','SMS') and lead_status in ('Assigned','Expired','Converted','In Process','Dead','New');

SELECT event_date,sol_id,customer_id,lead_status,lead_status_2,disposition_description_1,lead_id
FROM "l2karnatakabankdb"."acoe_crm_leads_prod" 
where campaign_name in ('Mutual Funds Cross Sell')
and channel in ('EMAIL','SMS') and lead_status in ('Assigned','Expired','Converted','In Process','Dead','New');

-- Group by SOL IDs summary:
SELECT sol_id,count(distinct customer_id)
FROM "l2karnatakabankdb"."acoe_crm_leads_prod" 
where campaign_name in ('Life Insurance Cross Sell')
and channel = 'BB'
group by 1;

SELECT sol_id,count(distinct customer_id)
FROM "l2karnatakabankdb"."acoe_crm_leads_prod" 
where campaign_name in ('General Insurance Cross-Sell')
and channel = 'BB'
group by 1;

SELECT sol_id,count(distinct customer_id)
FROM "l2karnatakabankdb"."acoe_crm_leads_prod" 
where campaign_name in ('Mutual Funds Cross Sell')
and channel in ('EMAIL','SMS') and lead_status in ('Assigned','Expired','Converted','In Process','Dead','New')
group by 1;

SELECT sol_id,count(distinct customer_id)
FROM "l2karnatakabankdb"."acoe_crm_leads_prod" 
where campaign_name in ('Life Insurance Cross Sell')
and channel in ('EMAIL','SMS') and lead_status in ('Assigned','Expired','Converted','In Process','Dead','New')
group by 1;


-- Summary count of customers





