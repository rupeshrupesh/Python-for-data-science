CREATE TABLE IF NOT EXISTS analytics_db.l1_fisdom_mutual_funds_customer_level_summary
WITH (format='PARQUET', external_location='s3://analytics-karnatakabank-bucket/Analytics_tables/mutual_funds_cross_sell/L1_tables/Customer_level_data') AS
with data AS 
(
select cust_id,user_key,subbroker,user_name AS fintech_user_name,acct_name AS gam_acct_name,primary_bank_name,primary_account_number as fisdom_primary_account_number,
foracid,acid,schm_type,acct_opn_date,acct_cls_date,customer_id AS fisdom_customer_id,sol_id,
date(date_parse(first_trxn_date,'%d-%m-%Y' )) as first_trxn_date,
date(date_parse(last_trxn_date,'%d-%m-%Y' ))as last_trxn_date,cast(no_of_funds as integer) as no_of_funds,
cast(nullif(no_of_active_funds,'') as integer) as no_of_active_funds,umrn,
date(date_parse(nullif(last_app_launch_date,''),'%d-%m-%Y' )) as last_app_launch_date,
cast(nullif(replace(replace(app_launch_in_last_90_days,',',''), ' -   ','0'),'') as integer) AS app_launch_in_last_90_days,
cast(nullif(replace(replace(sip_amount,',',''), ' -   ','0'),'') as integer) as sip_amount,
cast(nullif(replace(replace(onetime_amount,',',''), ' -   ','0'),'') as integer) as onetime_amount,investment_preference,
cast(nullif(replace(replace(aum_as_of_mar_20,',',''), ' -   ','0'),'') as integer) AS aum_as_of_mar_20,
cast(nullif(replace(replace(aum_as_of_mar_21,',',''), ' -   ','0'),'') as integer) as aum_as_of_mar_21,
cast(nullif(replace(replace(aum_as_of_mar_22,',',''), ' -   ','0'),'') as integer) as aum_as_of_mar_22,
cast(nullif(replace(replace(aum_as_of_mar_23,',',''), ' -   ','0'),'') as integer) as aum_as_of_mar_23,
cast(nullif(replace(replace(aum_as_on_dec_23,',',''), ' -   ','0'),'') as integer) as aum_as_on_dec_23 
from analytics_db.fisdom_mutual_funds_customer_level_summary left join l0karnatakabankstg.general_acct_mast_table on 
substr(lpad(primary_account_number,16,'0'),1,14) = substr(foracid,1,14)
)
select cust_id,data.*,
region_name,dp_code,constitution_desc,cust_constitution_code,cust_dob,occupation_desc,cust_age 
from data
LEFT JOIN l0karnatakabankstg.service_outlet_table using (sol_id)
LEFT JOIN l1karnatakabankdb.customer_base using (cust_id);

----------------------------------------------------------------------------------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS analytics_db.l1_fisdom_mutual_funds_lumpsum_purchase_transctions
WITH (format='PARQUET', external_location='s3://analytics-karnatakabank-bucket/Analytics_tables/mutual_funds_cross_sell/L1_tables/Lumpsum_purchase_transactions') AS
select cust_id,user_key,primary_account_number AS fisdom_primary_account_number,foracid,scheme_type,amc,scheme_name,isin,
cast(nullif(replace(replace(amount,',',''), ' -   ','0'),'') as integer) as amount, 
date(date_parse(nullif(investment_date,''),'%d-%m-%Y' )) as investment_date	 
from fisdom_mutual_funds_lumpsum_purchase_transctions left join l0karnatakabankstg.general_acct_mast_table
on substr(lpad(primary_account_number,16,'0'),1,14) = substr(foracid,1,14);

---------------------------------------------------------------------------------------------------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS analytics_db.l1_fisdom_mutual_funds_redemption_transctions
WITH (format='PARQUET', external_location='s3://analytics-karnatakabank-bucket/Analytics_tables/mutual_funds_cross_sell/L1_tables/Redemptions') AS
select cust_id,user_key,primary_account_number AS fisdom_primary_account_number,foracid,scheme_type,amc,scheme_name,isin,
cast(nullif(replace(replace(amount,',',''), ' -   ','0'),'') as integer) as amount,
date(date_parse(nullif(redemption_date,''),'%d-%m-%Y' )) AS redemption_date
from analytics_db.fisdom_mutual_funds_redemption_transctions
left join l0karnatakabankstg.general_acct_mast_table on substr(lpad(primary_account_number,16,'0'),1,14) = substr(foracid,1,14);

--------------------------------------------------------------------------------------------------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS analytics_db.l1_fisdom_mutual_funds_sip_purchase_transctions
WITH (format='PARQUET', external_location='s3://analytics-karnatakabank-bucket/Analytics_tables/mutual_funds_cross_sell/L1_tables/SIP_purchase_transactions') AS
select cust_id,user_key,primary_account_number AS fisdom_primary_account_number,foracid,
scheme_type,amc,scheme_name,isin,
cast(nullif(replace(replace(sip_amount,',',''), ' -   ','0'),'') as integer) as sip_amount,sip_status,
date(date_parse(nullif(sip_start_date,''),'%d-%m-%Y' )) as sip_start_date,
date(date_parse(nullif(trim(sip_cancellation_date),''),'%d-%m-%Y' )) AS sip_cancellation_date,
cast(nullif(replace(replace(successful_installments,',',''), ' -   ','0'),'') as integer) as successful_installments
from analytics_db.fisdom_mutual_funds_sip_purchase_transctions 
left join l0karnatakabankstg.general_acct_mast_table on substr(lpad(primary_account_number,16,'0'),1,14) = substr(foracid,1,14);

-----------------------------------------------------------------------------------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS analytics_db.l1_amc_mutual_funds_data
WITH (format='PARQUET', external_location='s3://analytics-karnatakabank-bucket/Analytics_tables/mutual_funds_cross_sell/L1_tables/amc_mutual_funds_data') AS
select CASE WHEN cust_id = '0' THEN NULL ELSE lpad(cust_id,9,'0') END AS cust_id,invstate, fmcode, td_fund,cast(td_acno as bigint) as td_acno ,
schpln,divopt,funddesc,td_purred,cast(td_trno as bigint) as td_trno,smcode,cast(nullif(chqno,'') as int) as chqno,
invname,trnmode, trnstat,td_branch,cast(isctrno as int) isctrno,date(date_parse(td_trdt,'%d-%m-%Y')) as td_trdt,
date(date_parse(td_prdt,'%d-%m-%Y')) as td_prdt,cast(td_pop as double )td_pop,cast(loadper as double) as loadper,cast(td_units as double) td_units,cast(td_amt as double)td_amt,cast(load1 as double) load1,td_agent,td_broker,cast(brokper as int)brokper,cast(brokcomm as int) as brokcomm,invid,date(date_parse(crdate,'%d-%m-%Y')) as crdate,cast(crtime as int) crtime,trnsub,td_appno,unqno,trdesc,td_trtype,date(date_parse(nullif(purdate,''),'%d-%m-%Y')) as purdate,cast(nullif(puramt,'') as double) puramt,cast(nullif(purunits,'') as double)purunits,trflag,date(date_parse(nullif(sfunddt,''),'%d-%m-%Y')) as sfunddt ,chqdate,chqbank,cast(td_nav as double) as td_nav,cast(td_ptrno as int) as td_ptrno,stt, cast(nullif(ihno,'') as double) as ihno,branchcode,inwardno,nctremarks,trcharges, sipregdt,sipregslno,divper,can,exchorgtr0,electrxnf1,cleared
from analytics_db.amc_mutual_funds_data;