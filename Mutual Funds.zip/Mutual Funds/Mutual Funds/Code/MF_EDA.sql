----------------------------------------------------------------------------------------------------------------------------------------------------

SELECT 
sum(aum_as_of_mar_20) as mar20_aum,
count(case when first_trxn_date <= date('2020-03-31') then 1 else null end) as mar_20_customers,
--
sum(aum_as_of_mar_21) AS mar21_aum,
count(case when first_trxn_date <= date('2021-03-31') then 1 else null end) as mar_21_customers,
--
sum(aum_as_of_mar_22) as mar22_aum,
count(case when first_trxn_date <= date('2022-03-31') then 1 else null end) as mar_22_customers,
--
sum(aum_as_of_mar_23) as mar23_aum,
count(case when first_trxn_date <= date('2023-03-31') then 1 else null end) as mar_23_customers,
--
sum(aum_as_on_dec_23) as dec23_aum,
count(case when first_trxn_date <= date('2023-12-31') then 1 else null end) as dec_23_customers
FROM "analytics_db"."l1_fisdom_mutual_funds_customer_level_summary";


SELECT 
sum(CASE WHEN first_trxn_date BETWEEN date('2019-04-01') AND date('2020-03-31') THEN aum_as_of_mar_20 END) as mar20_aum,
count(case when first_trxn_date BETWEEN date('2019-04-01') AND date('2020-03-31') then 1 else null end) as mar_20_customers,
--
sum(CASE WHEN first_trxn_date BETWEEN date('2020-04-01') AND date('2021-03-31') THEN aum_as_of_mar_21 END) AS mar21_aum,
count(case when first_trxn_date BETWEEN date('2020-04-01') AND date('2021-03-31') then 1 else null end) as mar_21_customers,
--
sum(CASE WHEN first_trxn_date BETWEEN date('2021-04-01') AND date('2022-03-31') THEN aum_as_of_mar_22 END) as mar22_aum,
count(case when first_trxn_date BETWEEN date('2021-04-01') AND date('2022-03-31') then 1 else null end) as mar_22_customers,
--
sum(CASE WHEN first_trxn_date BETWEEN date('2022-04-01') AND date('2023-03-31') THEN aum_as_of_mar_23 END) as mar23_aum,
count(case when first_trxn_date BETWEEN date('2022-04-01') AND date('2023-03-31') then 1 else null end) as mar_23_customers,
--
sum(CASE WHEN first_trxn_date > date('2023-03-31') THEN aum_as_on_dec_23 END) as dec23_aum,
count(case when first_trxn_date > date('2023-03-31') then 1 else null end) as dec_23_customers
FROM "analytics_db"."l1_fisdom_mutual_funds_customer_level_summary";

SELECT date_trunc('Month',first_trxn_date),count(1) FROM "analytics_db"."l1_fisdom_mutual_funds_customer_level_summary" GROUP BY 1 ORDER BY 1;


SELECT
region_name,dp_code,
count(case when first_trxn_date <= date('2020-03-31') then 1 else null end) as mar_20_customers,
count(case when first_trxn_date <= date('2021-03-31') then 1 else null end) as mar_21_customers,
count(case when first_trxn_date <= date('2022-03-31') then 1 else null end) as mar_22_customers,
count(case when first_trxn_date <= date('2023-03-31') then 1 else null end) as mar_23_customers,
count(case when first_trxn_date <= date('2023-12-31') then 1 else null end) as dec_23_customers,
--
sum(aum_as_of_mar_20) as mar20_aum,
sum(aum_as_of_mar_21) AS mar21_aum,
sum(aum_as_of_mar_22) as mar22_aum,
sum(aum_as_of_mar_23) as mar23_aum,
sum(aum_as_on_dec_23) as dec23_aum
FROM "analytics_db"."l1_fisdom_mutual_funds_customer_level_summary"
GROUP BY 1,2;


SELECT
occupation_desc,
count(case when first_trxn_date <= date('2020-03-31') then 1 else null end) as mar_20_customers,
count(case when first_trxn_date <= date('2021-03-31') then 1 else null end) as mar_21_customers,
count(case when first_trxn_date <= date('2022-03-31') then 1 else null end) as mar_22_customers,
count(case when first_trxn_date <= date('2023-03-31') then 1 else null end) as mar_23_customers,
count(case when first_trxn_date <= date('2023-12-31') then 1 else null end) as dec_23_customers,
--
sum(aum_as_of_mar_20) as mar20_aum,
sum(aum_as_of_mar_21) AS mar21_aum,
sum(aum_as_of_mar_22) as mar22_aum,
sum(aum_as_of_mar_23) as mar23_aum,
sum(aum_as_on_dec_23) as dec23_aum
FROM "analytics_db"."l1_fisdom_mutual_funds_customer_level_summary"
GROUP BY 1;

SELECT
case 
when cust_age <  25 then 'A. Below 25'
when cust_age <= 30 then 'B. 25 to 30'
when cust_age <= 35 then 'C. 30 to 35'
when cust_age <= 40 then 'D. 35 to 40'
when cust_age <= 45 then 'E. 40 to 45'
when cust_age <= 50 then 'F. 45 to 50'
when cust_age <= 60 then 'F. 50 to 60'
when cust_age <= 65 then 'F. 55 to 60'
when cust_age <= 80 then 'G. 60 to 70'
else 'H. Above 70' END age_band,
count(case when first_trxn_date <= date('2020-03-31') then 1 else null end) as mar_20_customers,
count(case when first_trxn_date <= date('2021-03-31') then 1 else null end) as mar_21_customers,
count(case when first_trxn_date <= date('2022-03-31') then 1 else null end) as mar_22_customers,
count(case when first_trxn_date <= date('2023-03-31') then 1 else null end) as mar_23_customers,
count(case when first_trxn_date <= date('2023-12-31') then 1 else null end) as dec_23_customers,
--
sum(aum_as_of_mar_20) as mar20_aum,
sum(aum_as_of_mar_21) AS mar21_aum,
sum(aum_as_of_mar_22) as mar22_aum,
sum(aum_as_of_mar_23) as mar23_aum,
sum(aum_as_on_dec_23) as dec23_aum
FROM "analytics_db"."l1_fisdom_mutual_funds_customer_level_summary"
GROUP BY 1;



SELECT
primary_bank_name,
count(case when first_trxn_date <= date('2020-03-31') then 1 else null end) as mar_20_customers,
count(case when first_trxn_date <= date('2021-03-31') then 1 else null end) as mar_21_customers,
count(case when first_trxn_date <= date('2022-03-31') then 1 else null end) as mar_22_customers,
count(case when first_trxn_date <= date('2023-03-31') then 1 else null end) as mar_23_customers,
count(case when first_trxn_date <= date('2023-12-31') then 1 else null end) as dec_23_customers,
--
sum(aum_as_of_mar_20) as mar20_aum,
sum(aum_as_of_mar_21) AS mar21_aum,
sum(aum_as_of_mar_22) as mar22_aum,
sum(aum_as_of_mar_23) as mar23_aum,
sum(aum_as_on_dec_23) as dec23_aum
FROM "analytics_db"."l1_fisdom_mutual_funds_customer_level_summary"
GROUP BY 1;


SELECT
CASE WHEN LENGTH(fisdom_customer_id) = 0 THEN 'direct' ELSE 'kbl_app' END AS onboarding_type,
count(case when first_trxn_date <= date('2020-03-31') then 1 else null end) as mar_20_customers,
count(case when first_trxn_date <= date('2021-03-31') then 1 else null end) as mar_21_customers,
count(case when first_trxn_date <= date('2022-03-31') then 1 else null end) as mar_22_customers,
count(case when first_trxn_date <= date('2023-03-31') then 1 else null end) as mar_23_customers,
count(case when first_trxn_date <= date('2023-12-31') then 1 else null end) as dec_23_customers,
--
sum(aum_as_of_mar_20) as mar20_aum,
sum(aum_as_of_mar_21) AS mar21_aum,
sum(aum_as_of_mar_22) as mar22_aum,
sum(aum_as_of_mar_23) as mar23_aum,
sum(aum_as_on_dec_23) as dec23_aum
FROM "analytics_db"."l1_fisdom_mutual_funds_customer_level_summary"
GROUP BY 1;

SELECT 
CASE
WHEN aum_as_of_mar_20 = 0       THEN 'A. Zero AUM'
WHEN aum_as_of_mar_20 <  1000   THEN 'B.Below 1000'
WHEN aum_as_of_mar_20 <= 5000   THEN 'C.1k to 5k'
WHEN aum_as_of_mar_20 <= 10000  THEN 'D.5k to 10k '
WHEN aum_as_of_mar_20 <= 50000  THEN 'E.10k to 50k'
WHEN aum_as_of_mar_20 <= 100000 THEN 'F.50k to 1L '
WHEN aum_as_of_mar_20 <= 200000 THEN 'G.1L to 2L'
WHEN aum_as_of_mar_20 >  200000 THEN 'H. Above 2L'
ELSE 'misising' END AS mar_20_aum_bucket,
count(case when first_trxn_date <= date('2020-03-31') then 1 else null end) as mar_20_customers,
sum(aum_as_of_mar_20) as mar20_aum
FROM "analytics_db"."l1_fisdom_mutual_funds_customer_level_summary"
group by 1 order by 1;

SELECT 
CASE
WHEN aum_as_on_dec_23 = 0       THEN 'A. Zero AUM'
WHEN aum_as_on_dec_23 <  1000   THEN 'B.Below 1000'
WHEN aum_as_on_dec_23 <= 5000   THEN 'C.1k to 5k'
WHEN aum_as_on_dec_23 <= 10000  THEN 'D.5k to 10k '
WHEN aum_as_on_dec_23 <= 50000  THEN 'E.10k to 50k'
WHEN aum_as_on_dec_23 <= 100000 THEN 'F.50k to 1L '
WHEN aum_as_on_dec_23 <= 200000 THEN 'G.1L to 2L'
WHEN aum_as_on_dec_23 >  200000 THEN 'H. Above 2L'
ELSE 'misising' END AS mar_23_aum_bucket,
count(case when first_trxn_date <= date('2023-12-31') then 1 else null end) as mar_23_customers,
sum(aum_as_on_dec_23) as mar20_aum
FROM "analytics_db"."l1_fisdom_mutual_funds_customer_level_summary"
group by 1 order by 1;

SELECT
CASE 
	WHEN COALESCE(no_of_active_funds,0) = 0 and aum_as_on_dec_23 = 0 THEN 'A. Zero'
	WHEN COALESCE(no_of_active_funds,0) = 1 THEN 'B. Only 1'
	WHEN COALESCE(no_of_active_funds,0) = 2 THEN 'C. Two'	
	WHEN COALESCE(no_of_active_funds,0) BETWEEN 3 and 5 THEN 'D. 3 to 5'
	WHEN COALESCE(no_of_active_funds,0) BETWEEN 5 and 10 THEN 'E. 5 to 10'
	WHEN COALESCE(no_of_active_funds,0) > 10 THEN 'F. Above 10'
	ELSE 'B. Only 1'
END AS no_of_funds_bands,
count(case when first_trxn_date <= date('2023-12-31') then 1 else null end) as mar_23_customers,
sum(aum_as_on_dec_23) as mar20_aum
FROM "analytics_db"."l1_fisdom_mutual_funds_customer_level_summary"
group by 1 ORDER BY 1;

SELECT
investment_preference,
count(case when first_trxn_date <= date('2023-12-31') then 1 else null end) as mar_23_customers,
sum(aum_as_on_dec_23) as mar20_aum
FROM "analytics_db"."l1_fisdom_mutual_funds_customer_level_summary"
group by 1 ORDER BY 1;

----------------------------------------------------------------------------------------------------------------------------------------------------

td_purred
trnmode
td_trdt
td_amt
trdesc
td_trtype
puramt
chqbank
invstate

SELECT split_part(funddesc,' ',1) as fund_house,td_purred,count(distinct cust_id),count(1),sum(td_amt)/10000000 FROM "analytics_db"."l1_amc_mutual_funds_data"
where cust_id is not null
group by 1,2 order by 3 desc;

SELECT chqbank,count(distinct cust_id),count(1),sum(td_amt)/10000000 FROM "analytics_db"."l1_amc_mutual_funds_data"
where cust_id is not null
group by 1 order by 2 desc;

SELECT invstate,count(distinct cust_id),count(1),sum(td_amt)/10000000 FROM "analytics_db"."l1_amc_mutual_funds_data"
where cust_id is not null
group by 1 order by 2 desc;

WITH base AS
(
SELECT cust_id,region_name,dp_code,ROW_NUMBER() OVER (PARTITION BY cust_id ORDER BY acct_opn_date desc) AS rnk
FROM  "l0karnatakabankstg"."general_acct_mast_table"
LEFT JOIN  "l0karnatakabankstg"."service_outlet_table" USING (sol_id)
WHERE cust_id IN (SELECT DISTINCT cust_id FROM "analytics_db"."l1_amc_mutual_funds_data" where  cust_id IS NOT NULL)
)
SELECT region_name,dp_code,count(distinct cust_id),count(1),sum(td_amt)/10000000 
FROM "analytics_db"."l1_amc_mutual_funds_data" left JOIN base USING (cust_id)
where cust_id is not null and rnk = 1 and td_purred = 'P'
and td_trdt > date('2022-03-31')
group by 1,2 order by 5;

----------------------------------------------------------------------------------------------------------------------------------------------------

select year,month,avg(mab),avg(meb)
from analytics_db.l1_fisdom_mutual_funds_customer_level_summary a
inner join mab_meb_incremental_master b on a.acid = b.acid
inner join casa_master c on a.acid = c.acid
where year= 2023
and a.acid is not null 
and a.schm_type = 'SBA'
and aum_as_on_dec_23 > 0
group by 1,2;


select year,month,avg(mab),avg(meb)
from
mab_meb_incremental_master a inner join casa_master b on a.acid = b.acid
and a.schm_type = 'SBA' and b.schm_type = 'SBA'
and b.acc_status = 'A'
and year = 2023
group by 1,2 order by 1,2;

----------------------------------------------------------------------------------------------------------------------------------------------------
select year,month,avg(mab),avg(meb)
from analytics_db.l1_fisdom_mutual_funds_customer_level_summary a
inner join mab_meb_incremental_master b on a.acid = b.acid
where year= 2023
and a.acid is not null 
and a.schm_type = 'SBA'
and aum_as_on_dec_23 > 0
group by 1,2 order by 1,2;

select year,month,avg(mab),avg(meb)
from
mab_meb_incremental_master a inner join casa_master b on a.acid = b.acid
and a.schm_type = 'SBA' and b.schm_type = 'SBA'
and b.acc_status = 'A'
and year = 2023
group by 1,2 order by 1,2;

----------------------------------------------------------------------------------------------------------------------------------------------------
-- Total base
select count(distinct cust_id) from l1karnatakabankdb.casa_master 
where acct_cls_date is null and acc_status = 'A' and schm_type IN ('SBA','CAA')

select count(distinct cust_id) from l1karnatakabankdb.fd_base_table 
where acct_cls_date is null and cust_id in (select distinct cust_id from l1karnatakabankdb.casa_master 
where acct_cls_date is null and acc_status = 'A' and schm_type IN ('SBA','CAA'))

select count(distinct cust_id) from l1karnatakabankdb.asset_base_table 
where acct_cls_date is null and cust_id in (select distinct cust_id from l1karnatakabankdb.casa_master 
where acct_cls_date is null and acc_status = 'A' and schm_type IN ('SBA','CAA'))

select count(distinct cust_id) from l0karnatakabankstg.li_tpp_view 
WHERE cust_id in (select distinct cust_id from l1karnatakabankdb.casa_master 
WHERE acc_status = 'A' and schm_type IN ('SBA','CAA'))

-- MF base
select count(distinct cust_id) from l1karnatakabankdb.fd_base_table 
where acct_cls_date is null and cust_id in (select distinct cust_id from analytics_db.l1_fisdom_mutual_funds_customer_level_summary
where  cust_id IS NOT null and aum_as_on_dec_23 > 0)

select count(distinct cust_id) from l1karnatakabankdb.asset_base_table 
where acct_cls_date is null and cust_id in (select distinct cust_id from analytics_db.l1_fisdom_mutual_funds_customer_level_summary
where  cust_id IS NOT null and aum_as_on_dec_23 > 0)

select count(distinct cust_id) from l0karnatakabankstg.li_tpp_view 
where cust_id in ((select distinct cust_id from analytics_db.l1_fisdom_mutual_funds_customer_level_summary
where  cust_id IS NOT null and aum_as_on_dec_23 > 0)


----------------------------------------------------------------------------------------------------------------------------------------------------
-- On-us events
with events as
(
SELECT date_trunc('Month',sip_start_date) as tran_month,sip_amount AS tran_amount,cust_id 
FROM "analytics_db"."l1_fisdom_mutual_funds_sip_purchase_transctions"
where cust_id is not null
union all
SELECT date_trunc('Month',investment_date) as tran_month,amount AS tran_amount,cust_id 
FROM "analytics_db"."l1_fisdom_mutual_funds_lumpsum_purchase_transctions"
where cust_id is not null
union all
SELECT date_trunc('Month',td_trdt) as tran_month,td_amt AS tran_amount,cust_id 
FROM "analytics_db"."l1_amc_mutual_funds_data"
where cust_id is not null and td_purred = 'P'
)
select tran_month,count(distinct cust_id),sum(tran_amount) from events
where tran_month >= date('2022-04-01')
group by 1 order by 1;

with event as
(
SELECT date_trunc('Month',sip_start_date) as tran_month,cust_id 
FROM "analytics_db"."l1_fisdom_mutual_funds_sip_purchase_transctions"
where cust_id is not null
union all
SELECT date_trunc('Month',investment_date) as tran_month,cust_id 
FROM "analytics_db"."l1_fisdom_mutual_funds_lumpsum_purchase_transctions"
where cust_id is not null
union all
SELECT date_trunc('Month',td_trdt) as tran_month,cust_id 
FROM "analytics_db"."l1_amc_mutual_funds_data"
where cust_id is not null and td_purred = 'P'
)
select tran_month,count(distinct cust_id) from events 
WHERE cust_id IN (select count(distinct cust_id from l1karnatakabankdb.casa_master 
where acct_cls_date is null and acc_status = 'A' and schm_type IN ('SBA','CAA'))
AND cust_id IN (SELECT DISTINCT cust_id FROM l1karnatakabankdb.customer_base WHERE cust_age BETWEEN 21 TO 70)
group by 1 order by 1;

----------------------------------------------------------------------------------------------------------------------------------------------------
--Off-us events
with event as
(
SELECT DISTINCT cust_id AS cust_id
FROM "analytics_db"."l1_fisdom_mutual_funds_customer_level_summary"
where cust_id is not null
union
SELECT DISTINCT cust_id AS cust_id
FROM "analytics_db"."l1_amc_mutual_funds_data"
where cust_id is not null and td_purred = 'P'
)
select year,month,count(distinct cust_id),sum(tran_amt) 
from  l2karnatakabankdb.transaction_master 
where payment_type2 = 'Broking'
and ((YEAR = 2022 AND MONTH >= 4) OR YEAR = 2023) 
and part_tran_type = 'D'
AND tran_amt > 100 
and self_transfer = 'N' and "include/exclude" = 'Y' 
AND cust_id NOT IN (SELECT cust_id FROM event)
group by 1,2 order by 1,2;

select utility_name,count(distinct cust_id),sum(tran_amt)
 from l2karnatakabankdb.transaction_master where product = 'Mutual fund payment'
 and ((YEAR = 2022 AND MONTH >= 4) OR YEAR = 2023)
 group by 1 ORDER BY 3 DESC;



with kbl_events as
(
SELECT cust_id,sip_amount AS inv_amount 
FROM "analytics_db"."l1_fisdom_mutual_funds_sip_purchase_transctions"
where cust_id is not NULL AND sip_start_date BETWEEN date('2022-04-01') AND last_day_of_month(date('2022-04-01'))
union all
SELECT cust_id,amount AS inv_amount 
FROM "analytics_db"."l1_fisdom_mutual_funds_lumpsum_purchase_transctions"
where cust_id is not NULL AND investment_date BETWEEN date('2022-04-01') AND last_day_of_month(date('2022-04-01'))
union all
SELECT cust_id,td_amt AS inv_amount 
FROM "analytics_db"."l1_amc_mutual_funds_data"
where cust_id is not null and td_purred = 'P' AND td_trdt BETWEEN date('2022-04-01') AND last_day_of_month(date('2022-04-01'))
)
select year,month,count(distinct cust_id),sum(tran_amt) 
from  l2karnatakabankdb.transaction_master 
where payment_type2 = 'Broking'
and ((YEAR = 2022 AND MONTH >= 4) OR YEAR = 2023) 
and part_tran_type = 'D'
AND tran_amt > 100 
and self_transfer = 'N' and "include/exclude" = 'Y' 
AND cust_id NOT IN (SELECT cust_id FROM kbl_events)
group by 1,2 order by 1,2;