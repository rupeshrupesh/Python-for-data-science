------------- QUERY FOR TOTAL INVESTMENTS --------------------------------------
with km_ctl as
(
SELECT
'fisdom_lumpsum' as source,
cust_id,
amount as amount,
case when cust_id is not null then amount end as amount_with_cust_id
FROM "l1karnatakabankdb"."fisdom_mutual_funds_lumpsum_purchase_transactions" 
where year(investment_date) = year(date('2024-05-01')) and month(investment_date) = month(date('2024-05-01'))
union all
SELECT
'fisdom_sip' as source,
cust_id,
sip_amount as amount,
case when cust_id is not null then sip_amount end as amount_with_cust_id
FROM "l1karnatakabankdb"."fisdom_mutual_funds_sip_transactions" 
where year(sip_start_date) = year(date('2024-05-01')) and month(sip_start_date) = month(date('2024-05-01'))
union all
select
'kfintech' as source,
cust_id,
td_amt as amount,
case when cust_id is not null then td_amt end as amount_with_cust_id
FROM "l1karnatakabankdb"."kfintech_amc_mf_data"
where td_purred = 'P'
and year(td_trdt) = year(date('2024-05-01')) and month(td_trdt) = month(date('2024-05-01'))
union all
select
'CAMS' as source,
cust_id,
amount as amount,
case when cust_id is not null then amount end as amount_with_cust_id 
FROM "l1karnatakabankdb"."cams_amc_mf_data"
where trxn_mode = 'N'
and year(trad_date) = year(date('2024-05-01')) and month(trad_date) = month(date('2024-05-01'))
)
select count(distinct cust_id),sum(amount),sum(amount_with_cust_id) from km_ctl;

-- ACTIVE CUSTOMER BASE QUERY
select count(distinct cust_id) from l1karnatakabankdb.casa_master where acc_status = 'A' and acct_cls_date is null;

------------- TARGET BASE
SELECT count(distinct customer_id) FROM "l2karnatakabankdb"."acoe_crm_leads_input_history"
where 
substr(unique_id,1,6) in (substr('2024-05-01',1,4) || substr('2024-05-01',6,2))
and campaign_name = 'Mutual Funds Cross Sell' and control = 'N';

----------------------------- TARGET BASE CONVERSIONS
with km_ctl as
(
SELECT
'fisdom_lumpsum' as source,
cust_id,
amount as amount,
case when cust_id is not null then amount end as amount_with_cust_id
FROM "l1karnatakabankdb"."fisdom_mutual_funds_lumpsum_purchase_transactions" 
where year(investment_date) = year(date('2024-05-01')) and month(investment_date) = month(date('2024-05-01'))
union all
SELECT
'fisdom_sip' as source,
cust_id,
sip_amount as amount,
case when cust_id is not null then sip_amount end as amount_with_cust_id
FROM "l1karnatakabankdb"."fisdom_mutual_funds_sip_transactions" 
where year(sip_start_date) = year(date('2024-05-01')) and month(sip_start_date) = month(date('2024-05-01'))
union all
select
'kfintech' as source,
cust_id,
td_amt as amount,
case when cust_id is not null then td_amt end as amount_with_cust_id
FROM "l1karnatakabankdb"."kfintech_amc_mf_data"
where td_purred = 'P'
and year(td_trdt) = year(date('2024-05-01')) and month(td_trdt) = month(date('2024-05-01'))
union all
select
'CAMS' as source,
cust_id,
amount as amount,
case when cust_id is not null then amount end as amount_with_cust_id 
FROM "l1karnatakabankdb"."cams_amc_mf_data"
where trxn_mode = 'N'
and year(trad_date) = year(date('2024-05-01')) and month(trad_date) = month(date('2024-05-01'))
)
select count(distinct cust_id),sum(amount),sum(amount_with_cust_id) from km_ctl
where cust_id in 
(SELECT distinct customer_id FROM "l2karnatakabankdb"."acoe_crm_leads_input_history"
where 
substr(unique_id,1,6) in (substr('2024-05-01',1,4) || substr('2024-05-01',6,2))
and campaign_name = 'Mutual Funds Cross Sell' and control = 'N')
and amount_with_cust_id < 10000000;

------------------------------- CONTROL BASE

SELECT count(distinct customer_id) FROM "l2karnatakabankdb"."acoe_crm_leads_input_history"
where substr(unique_id,1,6) in (substr('2024-05-01',1,4) || substr('2024-05-01',6,2))
and campaign_name = 'Mutual Funds Cross Sell' and control = 'Y';

----------------------------- CONTROL BASE CONVERSIONS
with km_ctl as
(
SELECT
'fisdom_lumpsum' as source,
cust_id,
amount as amount,
case when cust_id is not null then amount end as amount_with_cust_id
FROM "l1karnatakabankdb"."fisdom_mutual_funds_lumpsum_purchase_transactions" 
where year(investment_date) = year(date('2024-05-01')) and month(investment_date) = month(date('2024-05-01'))
union all
SELECT
'fisdom_sip' as source,
cust_id,
sip_amount as amount,
case when cust_id is not null then sip_amount end as amount_with_cust_id
FROM "l1karnatakabankdb"."fisdom_mutual_funds_sip_transactions" 
where year(sip_start_date) = year(date('2024-05-01')) and month(sip_start_date) = month(date('2024-05-01'))
union all
select
'kfintech' as source,
cust_id,
td_amt as amount,
case when cust_id is not null then td_amt end as amount_with_cust_id
FROM "l1karnatakabankdb"."kfintech_amc_mf_data"
where td_purred = 'P'
and year(td_trdt) = year(date('2024-05-01')) and month(td_trdt) = month(date('2024-05-01'))
union all
select
'CAMS' as source,
cust_id,
amount as amount,
case when cust_id is not null then amount end as amount_with_cust_id 
FROM "l1karnatakabankdb"."cams_amc_mf_data"
where trxn_mode = 'N'
and year(trad_date) = year(date('2024-05-01')) and month(trad_date) = month(date('2024-05-01'))
)
select count(distinct cust_id),sum(amount),sum(amount_with_cust_id) from km_ctl
where cust_id in 
(SELECT distinct customer_id FROM "l2karnatakabankdb"."acoe_crm_leads_input_history"
where 
substr(unique_id,1,6) in (substr('2024-05-01',1,4) || substr('2024-05-01',6,2))
and campaign_name = 'Mutual Funds Cross Sell' and control = 'Y')
and amount_with_cust_id < 10000000;