CREATE TABLE IF NOT EXISTS analytics_db.mf_scored_base_apr22
WITH (format='PARQUET', external_location='s3://analytics-karnatakabank-bucket/Analytics_tables/mutual_funds_cross_sell/scoring/mf_scored_base_apr22') AS
WITH init_base AS
(
SELECT cust_id,date('2022-04-01') AS cohort,sol_id,acct_opn_date,cust_gender,occupation_desc,region_name,dp_code,acc_status,acct_cls_date,ignore_flag,
cast(round(date_diff('day',date(cust_dob),date('2022-04-01'))/365.25,0) as int) AS age,
case when (staffflag = 'N' or staffflag is null) then 1 else 0 end staff, 
ROW_NUMBER() OVER (PARTITION BY cust_id ORDER BY acct_opn_date desc) AS sol_rnk,cust_constitution_code,cust_nationality
FROM "l1karnatakabankdb"."casa_master"
INNER JOIN "l1karnatakabankdb"."customer_base" USING (cust_id)
LEFT JOIN "l0karnatakabankstg"."service_outlet_table" USING (sol_id)
--WHERE (acct_cls_date is NULL OR acct_cls_date > last_day_of_month(date('2022-04-01')))  
--AND acc_status = 'A' AND ignore_flag = 'N'
--AND schm_type IN ('SBA','CAA') 
--AND cust_constitution_code IN ('01','11')
--AND cust_nationality = 'N'
--AND acct_opn_date <= date_trunc('Month',date_add('month',-6,date('2022-04-01')))
--AND cast(round(date_diff('day',date(cust_dob),date('2022-04-01'))/365.25,0) as int) BETWEEN 21 AND 65
),
base AS
(
SELECT cust_id,cohort,sol_id,cust_gender,occupation_desc,region_name,dp_code,age,acc_status,acct_cls_date as acct_cls_dt,acct_opn_date as acct_opn_dt,ignore_flag,cust_constitution_code,cust_nationality,staff
FROM init_base WHERE sol_rnk = 1 
),-- 508795
	kbl_events as
	(
	SELECT cust_id,sip_amount AS inv_amount
	FROM "analytics_db"."l1_fisdom_mutual_funds_sip_purchase_transctions"
	where cust_id is not NULL AND sip_start_date BETWEEN date('2022-04-01') AND last_day_of_month(date('2022-04-01'))
	union all
	SELECT cust_id,amount AS inv_amount 
	FROM "analytics_db"."l1_fisdom_mutual_funds_lumpsum_purchase_transctions"
	where cust_id is not NULL AND investment_date BETWEEN date('2022-04-01') AND last_day_of_month(date('2022-04-01'))
	union all
	SELECT cust_id,td_amt AS inv_amount 
	FROM "analytics_db"."l1_amc_mutual_funds_data"
	where cust_id is not null and td_purred = 'P' AND td_trdt BETWEEN date('2022-04-01') AND last_day_of_month(date('2022-04-01'))
	),
	on_us_events AS
	(
	SELECT cust_id,sum(inv_amount) AS y_var_1_amt,1 AS y_var_1 FROM kbl_events GROUP BY 1
	),
event as
(
SELECT DISTINCT cust_id AS cust_id
FROM "l1karnatakabankdb"."fisdom_mutual_funds_customer_level_summary"
where cust_id is not null
union
SELECT DISTINCT cust_id AS cust_id
FROM "l1karnatakabankdb"."kfintech_amc_mf_data"
where cust_id is not null and td_purred = 'P'
),
off_us_events AS
(
select cust_id,sum(tran_amt) AS y_var_2_amt,1 AS y_var_2
from  base INNER JOIN l2karnatakabankdb.transaction_master USING (cust_id)
where payment_type2 = 'Broking'
and MONTH = MONTH(date('2022-04-01')) AND year = year(date('2022-04-01')) 
and part_tran_type = 'D'
AND tran_amt > 100 
and self_transfer = 'N' and "include/exclude" = 'Y'
AND cust_id NOT IN (SELECT cust_id FROM  event)
group by 1
),
l1m_balance AS
(
SELECT cust_id,
sum(CASE WHEN schm_type = 'SBA' THEN mab END) AS l1m_sba_bal,
sum(CASE WHEN schm_type = 'CAA' THEN mab END) AS l1m_caa_bal,
sum(CASE WHEN schm_type = 'TDA' THEN meb END) AS l1m_tda_bal
FROM base INNER JOIN "l1karnatakabankdb"."mab_meb_incremental_master" USING (cust_id) 
WHERE MONTH = MONTH(date_add('day',-1,date('2022-04-01'))) AND year = year(date_add('day',-1,date('2022-04-01')))
GROUP BY 1
),
l3m_balance AS
(
SELECT cust_id,
sum(CASE WHEN schm_type = 'SBA' THEN mab END) AS l3m_sba_bal,
sum(CASE WHEN schm_type = 'CAA' THEN mab END) AS l3m_caa_bal,
sum(CASE WHEN schm_type = 'TDA' THEN meb END) AS l3m_tda_bal
FROM base INNER JOIN "l1karnatakabankdb"."mab_meb_incremental_master" USING (cust_id) 
WHERE MONTH = MONTH(date_add('month',-3,date('2022-04-01'))) AND year = year(date_add('month',-3,date('2022-04-01')))
GROUP BY 1
),
l6m_balance AS
(
SELECT cust_id,
sum(CASE WHEN schm_type = 'SBA' THEN mab END) AS l6m_sba_bal,
sum(CASE WHEN schm_type = 'CAA' THEN mab END) AS l6m_caa_bal,
sum(CASE WHEN schm_type = 'TDA' THEN meb END) AS l6m_tda_bal
FROM base INNER JOIN "l1karnatakabankdb"."mab_meb_incremental_master" USING (cust_id) 
WHERE MONTH = MONTH(date_add('month',-6,date('2022-04-01'))) AND year = year(date_add('month',-6,date('2022-04-01')))
GROUP BY 1
),
td_vars AS
(
SELECT cust_id,
count(CASE WHEN acct_opn_date BETWEEN date_trunc('month',date_add('day',-1,date('2022-04-01'))) AND date_add('day',-1,date('2022-04-01')) 
THEN 1 END) AS l1m_fd_opended,
count(CASE WHEN acct_opn_date BETWEEN date_trunc('month',date_add('month',-3,date('2022-04-01'))) AND date_add('day',-1,date('2022-04-01')) 
THEN 1 END) AS l3m_fd_opended,
count(CASE WHEN acct_opn_date BETWEEN date_trunc('month',date_add('month',-6,date('2022-04-01'))) AND date_add('day',-1,date('2022-04-01')) 
THEN 1 END) AS l6m_fd_opended,
count(CASE WHEN acct_cls_date BETWEEN date_trunc('month',date_add('day',-1,date('2022-04-01'))) AND date_add('day',-1,date('2022-04-01')) 
THEN 1 END) AS l1m_fd_closed,
count(CASE WHEN acct_cls_date BETWEEN date_trunc('month',date_add('month',-3,date('2022-04-01'))) AND date_add('day',-1,date('2022-04-01')) 
THEN 1 END) AS l3m_fd_closed,
count(CASE WHEN acct_cls_date BETWEEN date_trunc('month',date_add('month',-6,date('2022-04-01'))) AND date_add('day',-1,date('2022-04-01')) 
THEN 1 END) AS l6m_fd_closed
FROM base INNER JOIN "l1karnatakabankdb"."fd_base_table" USING (cust_id)
GROUP BY 1
),
on_us_insurance_base AS
(
select cust_id,
case 
when regexp_like("date of issuance",'^..-...-....$') then date_parse("date of issuance",'%d-%b-%Y')
when regexp_like("date of issuance",'^....-..-.. ..:..:..$') then date_parse("date of issuance",'%Y-%m-%d %H:%i:%s')
when regexp_like("date of issuance",'^..-..-....$') then date_parse("date of issuance",'%d-%m-%Y')
else date("date of issuance") end as date_of_issuance
from l0karnatakabankstg.li_tpp_view
),
on_us_insurance AS
(
select cust_id,
count(1) AS insurance_purchase_lifetime_flag
from on_us_insurance_base 
WHERE date(date_of_issuance) < date('2022-04-01')
GROUP BY 1
),
on_us_mf as
(
SELECT DISTINCT cust_id,'Y' AS lifetime_mf_flag 
FROM "l1karnatakabankdb"."fisdom_mutual_funds_sip_transactions"
where cust_id is not NULL AND sip_start_date < date('2022-04-01')
union
SELECT DISTINCT cust_id,'Y' AS lifetime_mf_flag 
FROM "l1karnatakabankdb"."fisdom_mutual_funds_lumpsum_purchase_transactions"
where cust_id is not NULL AND investment_date < date('2022-04-01')
union
SELECT DISTINCT cust_id,'Y' AS lifetime_mf_flag 
FROM "l1karnatakabankdb"."kfintech_amc_mf_data"
where cust_id is not null and td_purred = 'P' AND td_trdt < date('2022-04-01')
),
mb_logins as
(
SELECT
	cust_id,
	count(DISTINCT(
	(CASE WHEN
	DATE(login_datetime) BETWEEN date_trunc('month', date_add('month',-3, date('2022-04-01'))) AND date_add('day',-1, date('2022-04-01'))
THEN (DATE(login_datetime)) END))) AS l3m_no_of_logins
FROM base a inner JOIN l0karnatakabankstg.usersloginhist b ON a.cust_id = b.user_id
GROUP BY 1
),
emi_base as
(
select cust_id,acid,flow_amt,shdl_num,row_number() OVER (PARTITION BY acid ORDER BY CAST(shdl_num AS int) desc) AS rnk
from base
inner join l1karnatakabankdb.asset_base_table using (cust_id)
inner join l0karnatakabankstg.la_rep_shdl_history_table using (acid)
where flow_id = 'EIDEM' and lr_freq_type = 'M'
AND acct_opn_date < date('2022-04-01')
AND (acct_cls_date is NULL OR acct_cls_date > date_add('day',-1, date('2022-04-01')))
and date('2022-04-01') >= date(flow_start_date)
),
emi as
(
select cust_id,count(acid) AS active_loan_accounts_at_snapshot,sum(flow_amt) AS total_emi_at_snapshot FROM emi_base GROUP BY 1
),
l6m_tran AS
(
SELECT cust_id,
count(case when part_tran_type = 'C' then 1 end) as l6m_credit_tran,
count(case when part_tran_type = 'D' then 1 end) as l6m_debit_tran,
--
count(distinct(case when part_tran_type = 'C' then tran_date end)) as l6m_credit_days,
count(distinct(case when part_tran_type = 'D' then tran_date end)) as l6m_debit_days,
count(distinct(tran_date)) as l3_debit_days,
--
sum(case when part_tran_type = 'C' then tran_amt end) as l6m_credit_tran_amt,
sum(case when part_tran_type = 'D' then tran_amt end) as l6m_debit_tran_amt,
--
count(case when part_tran_type = 'D' AND payment_type IN ('POS- Debit Card','ECOM-Debit Card') then 1 end) as l6m_debit_card_spend_tran,
sum(case when part_tran_type = 'D' AND payment_type  IN ('POS- Debit Card','ECOM-Debit Card') then tran_amt end) as l6m_debit_card_spend_amt,
--
count(case when part_tran_type = 'D' AND payment_type  IN ('Balance Inquiry Charges') then 1 end) as l6m_balance_inquiry_tran,
--
count(case when part_tran_type = 'D' AND payment_type2 IN ('Utility Bills') then 1 end) as l6m_utlility_bill_tran,
count(case when part_tran_type = 'D' AND payment_type2 IN ('Insurance') then 1 end) as l6m_insurance_premium_tran,
count(case when part_tran_type = 'D' AND payment_type2 IN ('Credit Card Payment') then 1 end) as l6m_credit_card_payment_tran,
--
count(case when part_tran_type = 'D' AND purpose IN ('Healthcare') then 1 end) as l6m_spend_on_healthcare_tran,
sum(case when part_tran_type = 'D' AND purpose IN ('Healthcare') then tran_amt end) as l6m_spend_on_healthcare_amt,
--
count(case when part_tran_type = 'D' AND purpose IN ('AMAZON/FLIPKART') then 1 end) as l6m_ecommerce_spends_tran,
sum(case when part_tran_type = 'D' AND purpose IN ('AMAZON/FLIPKART') then tran_amt end) as l6m_ecommerce_spends_amt
--
FROM base INNER JOIN "l2karnatakabankdb"."transaction_master" USING (cust_id)
where "include/exclude" = 'Y'
and 
(
(MONTH >= MONTH(date_add('month',-6,date('2022-04-01'))) and year = year(date_add('month',-6,date('2022-04-01'))))
or
(MONTH <= MONTH(date_add('day',-1,date('2022-04-01'))) and year =year(date_add('day',-1,date('2022-04-01'))))
)
and tran_crncy_code = 'INR' and schm_type in ('SBA','CAA')
group by 1
)
SELECT *
FROM base 
LEFT JOIN l1m_balance USING (cust_id)
LEFT JOIN l6m_balance USING (cust_id)
LEFT JOIN l3m_balance USING (cust_id)
LEFT JOIN td_vars USING (cust_id)
LEFT JOIN on_us_insurance USING (cust_id)
LEFT JOIN on_us_mf USING (cust_id)
LEFT JOIN mb_logins USING (cust_id)
LEFT JOIN emi USING (cust_id)
LEFT JOIN l6m_tran USING (cust_id)
LEFT JOIN on_us_events USING (cust_id)
LEFT JOIN off_us_events USING (cust_id);